"""Phase 5 - all figures for the report (PNG, 200 dpi)."""
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import config as C

R, F = C.RESULTS_DIR, C.FIG_DIR
F.mkdir(parents=True, exist_ok=True)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.spines.top": False,
                     "axes.spines.right": False, "savefig.dpi": 200, "savefig.bbox": "tight"})
LABEL = {t["key"]: t["label"] for t in C.TOKENIZERS}
LABEL["qwen2_5"] = "Qwen2.5 / Qwen3"
LABEL.update({t["key"]: t["label"].replace("Own BPE: ", "") for t in C.OWN_TOKENIZERS})
MAIN = [c for c, _, _ in C.MAIN_LANGS]

pl = pd.read_csv(R / "per_language_pretrained.csv")
pl = pl[pl.tokenizer != "qwen3"]                  # identical to Qwen2.5 (see extra_checks.json)
sm = pd.read_csv(R / "summary_pretrained.csv"); sm = sm[sm.tokenizer != "qwen3"]
order = sm.sort_values("main_mean_premium").tokenizer.tolist()
lang_order = (pl[pl.lang.isin(MAIN)].groupby("lang").premium.mean().sort_values().index.tolist())
NAMES = [C.LANG_NAME[l] for l in lang_order]

# 1 heat-map ------------------------------------------------------------------
M = pl.pivot(index="tokenizer", columns="lang", values="premium").loc[order, lang_order]
fig, ax = plt.subplots(figsize=(9, 3.8))
im = ax.imshow(np.log2(M.values), cmap="YlOrRd", vmin=0, vmax=np.log2(13), aspect="auto")
for i in range(M.shape[0]):
    for j in range(M.shape[1]):
        v = M.values[i, j]
        ax.text(j, i, f"{v:.1f}", ha="center", va="center", fontsize=8, color="white" if v > 5 else "black")
ax.set_xticks(range(len(NAMES)), NAMES, rotation=35, ha="right")
ax.set_yticks(range(len(order)), [LABEL[k] for k in order])
cb = fig.colorbar(im, ax=ax, ticks=np.log2([1, 2, 4, 8, 12])); cb.ax.set_yticklabels(["1×", "2×", "4×", "8×", "12×"])
cb.set_label("Token premium vs English")
fig.savefig(F / "fig5_1_premium_heatmap.png"); plt.close(fig)

# 2 mean premium per tokenizer with range --------------------------------------
fig, ax = plt.subplots(figsize=(7, 3.4))
y = np.arange(len(order))
s = sm.set_index("tokenizer").loc[order]
ax.hlines(y, s.main_min_premium, s.main_max_premium, color="#bbb", lw=3)
ax.plot(s.main_mean_premium, y, "o", color="#c0392b", ms=7, label="mean of 12 languages")
ax.plot(s.main_min_premium, y, "|", color="#555", ms=10); ax.plot(s.main_max_premium, y, "|", color="#555", ms=10)
for yi, v in zip(y, s.main_mean_premium):
    ax.text(v, yi - 0.25, f"{v:.2f}×", ha="center", fontsize=8)
ax.axvline(1, ls="--", color="k", lw=0.8); ax.text(1.05, len(order) - 0.6, "English = 1×", fontsize=8)
ax.set_yticks(y, [LABEL[k] for k in order]); ax.set_xscale("log", base=2)
ax.set_xticks([1, 2, 4, 8, 13], ["1×", "2×", "4×", "8×", "13×"])
ax.set_xlabel("Tokens needed for the same content, relative to English (bar = min–max over languages)")
ax.invert_yaxis(); ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.22), frameon=False)
fig.savefig(F / "fig5_2_premium_by_tokenizer.png"); plt.close(fig)

# 3 context capacity at 8k --------------------------------------------------------
sel = ["eng_Latn", "hin_Deva", "ben_Beng", "tam_Taml", "mal_Mlym", "ory_Orya"]
fig, ax = plt.subplots(figsize=(8, 3.4))
w = 0.8 / len(sel)
for k, l in enumerate(sel):
    vals = pl[pl.lang == l].set_index("tokenizer").loc[order, "eng_words_in_8192"]
    ax.bar(np.arange(len(order)) + (k - len(sel) / 2 + .5) * w, vals, w, label=C.LANG_NAME[l])
ax.set_xticks(range(len(order)), [LABEL[k] for k in order], rotation=20, ha="right")
ax.set_ylabel("English-equivalent words\nthat fit in an 8,192-token window")
ax.legend(ncol=6, fontsize=7.5, frameon=False, loc="upper center", bbox_to_anchor=(0.5, 1.13))
fig.savefig(F / "fig5_3_context_capacity.png"); plt.close(fig)

# 4 cost of 1,000 English-equivalent words at a flat token price -------------------
fig, ax = plt.subplots(figsize=(7.5, 3.4))
for k in ["gemma3", "gpt4o", "qwen2_5", "llama3_2"]:
    v = pl[pl.tokenizer == k].set_index("lang").loc[["eng_Latn"] + lang_order, "usd_per_1k_eng_equiv"] * 100
    ax.plot(range(len(v)), v, "o-", label=LABEL[k], ms=4)
ax.set_xticks(range(len(lang_order) + 1), ["English"] + NAMES, rotation=35, ha="right")
ax.set_ylabel(f"US cents per 1,000 English-equivalent\nwords (@ ${C.PRICE_PER_M_TOKENS_USD}/M tokens)")
ax.legend(frameon=False, fontsize=8)
fig.savefig(F / "fig5_4_cost.png"); plt.close(fig)

# 5 premium vs fragment share (why) ---------------------------------------------------
fig, axs = plt.subplots(1, 2, figsize=(9, 3.4))
m = pl[pl.lang.isin(MAIN)]
for k in order:
    g = m[m.tokenizer == k]
    axs[0].scatter(g.byte_premium, g.premium, s=14, label=LABEL[k])
    axs[1].scatter(g.fragment_share * 100, g.premium, s=14)
axs[0].set_xlabel("UTF-8 byte premium vs English"); axs[0].set_ylabel("Token premium vs English")
axs[1].set_xlabel("Tokens that are sub-character fragments (%)")
axs[0].legend(fontsize=7, frameon=False)
for a in axs: a.set_yscale("log", base=2); a.set_yticks([1, 2, 4, 8], ["1×", "2×", "4×", "8×"])
fig.savefig(F / "fig5_5_why.png"); plt.close(fig)

# 6 controlled experiment ---------------------------------------------------------------
po = pd.read_csv(R / "per_language_own.csv")
fig, ax = plt.subplots(figsize=(9, 3.4))
keys = ["own_eng", "own_skew", "own_bal"]; w = 0.27
langs = ["eng_Latn"] + lang_order
for k, key in enumerate(keys):
    v = po[po.tokenizer == key].set_index("lang").loc[langs, "tokens_per_eng_word"]
    ax.bar(np.arange(len(langs)) + (k - 1) * w, v, w, label=LABEL[key])
ax.set_xticks(range(len(langs)), ["English"] + NAMES, rotation=35, ha="right")
ax.set_ylabel("Tokens per English-equivalent word"); ax.legend(frameon=False)
fig.savefig(F / "fig5_6_controlled.png"); plt.close(fig)

# 7 extended languages (appendix) --------------------------------------------------------
EXT = [c for c, _, _ in C.EXTENDED_LANGS]
E = pl.pivot(index="tokenizer", columns="lang", values="premium").loc[order, EXT]
fig, ax = plt.subplots(figsize=(9, 3.6))
im = ax.imshow(np.log2(E.values), cmap="YlOrRd", vmin=0, vmax=np.log2(13), aspect="auto")
for i in range(E.shape[0]):
    for j in range(E.shape[1]):
        v = E.values[i, j]; ax.text(j, i, f"{v:.1f}", ha="center", va="center", fontsize=8, color="white" if v > 5 else "black")
ax.set_xticks(range(len(EXT)), [C.LANG_NAME[l] for l in EXT], rotation=35, ha="right")
ax.set_yticks(range(len(order)), [LABEL[k] for k in order])
fig.savefig(F / "figD_1_extended_heatmap.png"); plt.close(fig)
print("figures:", sorted(p.name for p in F.glob("*.png")))
