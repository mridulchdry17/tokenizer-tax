#!/usr/bin/env bash
# Reproduce the whole study (about 2 minutes on a laptop CPU).
set -e
cd "$(dirname "$0")"
[ -d ../flores200_dataset ] || (cd .. && git clone --depth 1 https://github.com/AleksandarPetrov/tokenization-fairness tf_src && mv tf_src/flores200_dataset . && rm -rf tf_src)
python 01_prepare_data.py
python 02_tokenize.py pretrained nfc
python 02_tokenize.py pretrained raw
python 03_train_tokenizers.py
python 02_tokenize.py own nfc
python 04_analyse.py
python 05_figures.py
python 06_examples.py
python -m pytest tests -v
