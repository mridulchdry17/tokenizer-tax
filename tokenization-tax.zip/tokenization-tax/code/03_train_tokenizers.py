"""Phase 3 - controlled experiment: train three byte-level BPE tokenizers with
the SAME algorithm and vocabulary size, changing ONLY the language mix of the
training text. Training text = FLORES 'dev' split (disjoint from 'devtest')."""
import json, random, unicodedata
import pandas as pd
from tokenizers import Tokenizer, models, trainers, pre_tokenizers, decoders, normalizers
import config as C

N_SENTENCES = 988              # every corpus holds the same number of sentences
SKEW_ENGLISH_SHARE = 0.90      # web-like mix: 90% of sentences English

def corpus(mix, dev, banned):
    """All three corpora contain the same number of sentences (i.e. the same
    amount of information, since FLORES is parallel); only the mix differs."""
    rng = random.Random(C.SEED)
    eng = C.REFERENCE[0]
    langs = [eng] + [c for c, _, _ in C.MAIN_LANGS]
    table = dev.pivot(index="sent_id", columns="lang", values="text")
    ok = [i for i in table.index if not any(table.at[i, l] in banned for l in langs)]
    order = rng.sample(ok, len(ok))
    if mix == "english":
        return [(eng, table.at[i, eng]) for i in order[:N_SENTENCES]]
    if mix == "skewed":
        n_eng = int(SKEW_ENGLISH_SHARE * N_SENTENCES)
        out = [(eng, table.at[i, eng]) for i in order[:n_eng]]
        per = (N_SENTENCES - n_eng) // (len(langs) - 1)
        rest = order[n_eng:]
        for k, l in enumerate(langs[1:]):
            out += [(l, table.at[i, l]) for i in rest[k * per:(k + 1) * per]]
        return out
    per = N_SENTENCES // len(langs)                     # balanced / parity
    return [(l, table.at[i, l]) for i in order[:per] for l in langs]

def train(texts):
    tok = Tokenizer(models.BPE())
    tok.normalizer = normalizers.NFC()
    tok.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=False)
    tok.decoder = decoders.ByteLevel()
    tr = trainers.BpeTrainer(vocab_size=C.OWN_VOCAB, min_frequency=1, show_progress=False,
                             initial_alphabet=pre_tokenizers.ByteLevel.alphabet())
    tok.train_from_iterator(texts, trainer=tr)
    return tok

if __name__ == "__main__":
    dev = pd.read_csv(C.DATA_DIR / f"flores_{C.TRAIN_SPLIT}.csv")
    test = pd.read_csv(C.DATA_DIR / f"flores_{C.SPLIT}.csv")
    banned = set(test.text)                       # never train on a test sentence
    outdir = C.RESULTS_DIR / "own_tokenizers"; outdir.mkdir(parents=True, exist_ok=True)
    summary = []
    for spec in C.OWN_TOKENIZERS:
        data = corpus(spec["mix"], dev, banned)
        texts = [unicodedata.normalize("NFC", s) for _, s in data]
        tok = train(texts)
        tok.save(str(outdir / f"{spec['key']}.json"))
        by_lang = pd.Series([l for l, _ in data]).value_counts()
        nbytes = sum(len(t.encode()) for t in texts)
        eng_share = sum(1 for l, _ in data if l == "eng_Latn") / len(data)
        summary.append(dict(key=spec["key"], sentences=len(texts), languages=len(by_lang),
                            vocab=tok.get_vocab_size(), english_sentence_share=round(eng_share, 3)))
        print(summary[-1])
    json.dump(summary, open(outdir / "training_summary.json", "w"), indent=2)
