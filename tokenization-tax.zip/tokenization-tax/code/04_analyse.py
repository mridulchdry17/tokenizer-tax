"""Phase 4 - turn per-sentence counts into the study's metrics:
fertility, premium vs English (with bootstrap CIs), sub-character fragments,
cost per 1,000 words and context-window capacity."""
import json
import numpy as np
import pandas as pd
from scipy import stats
import config as C

ENG = C.REFERENCE[0]
MAIN = [c for c, _, _ in C.MAIN_LANGS]
EXT = [c for c, _, _ in C.EXTENDED_LANGS]


def per_lang(counts: pd.DataFrame) -> pd.DataFrame:
    rng = np.random.default_rng(C.SEED)
    n = counts.sent_id.nunique()
    boots = rng.integers(0, n, size=(C.N_BOOTSTRAP, n))     # same resamples for every cell (paired)
    out = []
    for tk, g in counts.groupby("tokenizer"):
        piv = g.pivot(index="sent_id", columns="lang", values="tokens").sort_index()
        eng_tok = piv[ENG].to_numpy()
        eng_words = g[g.lang == ENG].set_index("sent_id").words.sort_index().to_numpy()
        for lang, gl in g.groupby("lang"):
            t = piv[lang].to_numpy()
            prem = t.sum() / eng_tok.sum()
            bs = t[boots].sum(1) / eng_tok[boots].sum(1)
            tot = gl[["tokens", "words", "chars", "bytes", "fragments"]].sum()
            tok_per_eng_word = tot.tokens / eng_words.sum()       # content-equivalent
            out.append(dict(
                tokenizer=tk, lang=lang, language=C.LANG_NAME[lang], script=C.LANG_SCRIPT[lang],
                group="ref" if lang == ENG else ("main" if lang in MAIN else "extended"),
                tokens=int(tot.tokens), words=int(tot.words), chars=int(tot.chars), bytes=int(tot.bytes),
                fertility=tot.tokens / tot.words,
                chars_per_token=tot.chars / tot.tokens,
                premium=prem, premium_lo=np.percentile(bs, 2.5), premium_hi=np.percentile(bs, 97.5),
                byte_premium=tot.bytes / g[g.lang == ENG].bytes.sum(),
                fragment_share=tot.fragments / tot.tokens,
                tokens_per_eng_word=tok_per_eng_word,
                usd_per_1k_words=tot.tokens / tot.words * 1000 * C.PRICE_PER_M_TOKENS_USD / 1e6,
                usd_per_1k_eng_equiv=tok_per_eng_word * 1000 * C.PRICE_PER_M_TOKENS_USD / 1e6,
                **{f"eng_words_in_{w}": w / tok_per_eng_word for w in C.CONTEXT_WINDOWS},
            ))
    return pd.DataFrame(out)


def summarise(pl: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for tk, g in pl.groupby("tokenizer"):
        m = g[g.group == "main"]
        e = g[g.group == "extended"]
        eng = g[g.group == "ref"].iloc[0]
        rows.append(dict(
            tokenizer=tk, eng_fertility=eng.fertility,
            main_mean_premium=m.premium.mean(), main_geo_premium=stats.gmean(m.premium),
            main_min_premium=m.premium.min(), main_min_lang=m.loc[m.premium.idxmin(), "language"],
            main_max_premium=m.premium.max(), main_max_lang=m.loc[m.premium.idxmax(), "language"],
            ext_mean_premium=e.premium.mean() if len(e) else np.nan,
            main_mean_fertility=m.fertility.mean(), main_fragment_share=m.fragment_share.mean(),
            spearman_bytes_vs_premium=stats.spearmanr(m.byte_premium, m.premium)[0],
        ))
    return pd.DataFrame(rows).sort_values("main_mean_premium")


if __name__ == "__main__":
    R = C.RESULTS_DIR
    out = {}
    for which in ("pretrained", "own"):
        f = R / f"sentence_counts_{which}.csv"
        if not f.exists():
            continue
        counts = pd.read_csv(f)
        pl = per_lang(counts)
        pl.to_csv(R / f"per_language_{which}.csv", index=False)
        sm = summarise(pl)
        sm.to_csv(R / f"summary_{which}.csv", index=False)
        print(f"\n== {which}\n", sm[["tokenizer", "eng_fertility", "main_mean_premium", "main_min_lang",
                                   "main_max_premium", "main_max_lang", "main_fragment_share"]].round(3).to_string(index=False))

    # NFC ablation: how many extra tokens does un-normalised text cost?
    raw_f = R / "sentence_counts_pretrained_raw.csv"
    if raw_f.exists():
        raw = pd.read_csv(raw_f).groupby(["tokenizer", "lang"]).tokens.sum()
        nfc = pd.read_csv(R / "sentence_counts_pretrained.csv").groupby(["tokenizer", "lang"]).tokens.sum()
        abl = ((raw - nfc) / nfc).rename("extra_share_raw").reset_index()
        abl.to_csv(R / "nfc_ablation.csv", index=False)
        out["nfc_max_extra"] = abl.sort_values("extra_share_raw").tail(5).to_dict("records")

    # do Qwen2.5 and Qwen3 tokenise identically?
    c = pd.read_csv(R / "sentence_counts_pretrained.csv")
    if {"qwen2_5", "qwen3"} <= set(c.tokenizer):
        a = c[c.tokenizer == "qwen2_5"].tokens.to_numpy(); b = c[c.tokenizer == "qwen3"].tokens.to_numpy()
        out["qwen25_vs_qwen3_identical_counts"] = bool((a == b).all())
    json.dump(out, open(R / "extra_checks.json", "w"), indent=2, default=float)
    print(json.dumps(out, indent=1, default=float)[:800])
