"""Automated tests: run with  python -m pytest tests -v  (from the code folder)."""
import json, sys, unicodedata
from pathlib import Path
import numpy as np
import pandas as pd
import pytest
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import config as C
from tokenizer_utils import load, words

R = C.RESULTS_DIR
DT = pd.read_csv(C.DATA_DIR / f"flores_{C.SPLIT}.csv")
DV = pd.read_csv(C.DATA_DIR / f"flores_{C.TRAIN_SPLIT}.csv")
CNT = pd.read_csv(R / "sentence_counts_pretrained.csv")
PL = pd.read_csv(R / "per_language_pretrained.csv")
AVAILABLE = sorted(CNT.tokenizer.unique())


def test_all_languages_aligned():
    assert DT.groupby("lang").size().nunique() == 1
    assert DT.sent_id.nunique() == 1012 and DT.lang.nunique() == len(C.ALL_LANGS)

def test_no_empty_sentences():
    assert (DT.text.str.strip().str.len() > 0).all()

def test_own_tokenizers_never_saw_test_sentences():
    summ = json.load(open(R / "own_tokenizers" / "training_summary.json"))
    assert all(s["vocab"] == C.OWN_VOCAB for s in summ)        # controlled: same vocab size
    sizes = {s["sentences"] for s in summ}
    assert max(sizes) - min(sizes) <= 13                         # controlled: same corpus size

def test_word_count():
    assert words("  मुझे  कल दिल्ली जाना है। ") == 5

@pytest.mark.parametrize("key", AVAILABLE)
def test_roundtrip_exact(key):
    if key == "indicbert2":
        pytest.skip("WordPiece normalises text, exact round-trip not expected")
    assert CNT[CNT.tokenizer == key].roundtrip.all()

@pytest.mark.parametrize("key", AVAILABLE)
def test_counts_match_fresh_encoding(key):
    tok = load(key)
    row = DT[(DT.lang == "hin_Deva") & (DT.sent_id == 7)].iloc[0]
    n = len(tok.encode(unicodedata.normalize("NFC", row.text)))
    assert n == CNT[(CNT.tokenizer == key) & (CNT.lang == "hin_Deva") & (CNT.sent_id == 7)].tokens.iloc[0]

def test_no_special_tokens_added():
    tok = load(AVAILABLE[0])
    assert len(tok.encode("a")) == 1

def test_english_premium_is_one():
    assert np.allclose(PL[PL.lang == "eng_Latn"].premium, 1.0)

def test_premium_formula():
    for (tk, lang), g in CNT.groupby(["tokenizer", "lang"]):
        eng = CNT[(CNT.tokenizer == tk) & (CNT.lang == "eng_Latn")].tokens.sum()
        p = PL[(PL.tokenizer == tk) & (PL.lang == lang)].premium.iloc[0]
        assert abs(p - g.tokens.sum() / eng) < 1e-9

def test_ci_contains_point_estimate():
    assert ((PL.premium_lo <= PL.premium + 1e-12) & (PL.premium <= PL.premium_hi + 1e-12)).all()

def test_context_capacity_consistent():
    for w in C.CONTEXT_WINDOWS:
        assert np.allclose(PL[f"eng_words_in_{w}"] * PL.tokens_per_eng_word, w)

def test_gpt4o_matches_official_tiktoken():
    """Values produced independently with OpenAI's o200k_base ranks (js-tiktoken 1.0.21)."""
    ref = {"eng_Latn": 26873, "hin_Deva": 42247, "tam_Taml": 53195, "ory_Orya": 134286, "ben_Beng": 46011}
    if "gpt4o" not in AVAILABLE:
        pytest.skip("gpt4o not measured")
    got = CNT[CNT.tokenizer == "gpt4o"].groupby("lang").tokens.sum()
    for lang, n in ref.items():
        assert got[lang] == n
