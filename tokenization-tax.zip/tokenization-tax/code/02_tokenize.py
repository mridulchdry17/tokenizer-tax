"""Phase 2 - tokenise every devtest sentence with every tokenizer and record
tokens, words, characters, UTF-8 bytes and sub-character fragments."""
import sys, time, unicodedata
import pandas as pd
import config as C
from tokenizer_utils import load, words

def run(keys, norm="nfc"):
    df = pd.read_csv(C.DATA_DIR / f"flores_{C.SPLIT}.csv")
    if norm == "nfc":   # canonical Unicode form, as most apps/IMEs produce
        df["text"] = df.text.map(lambda s: unicodedata.normalize("NFC", s))
    rows, meta = [], []
    for key in keys:
        try:
            tok = load(key)
        except Exception as e:
            print(f"  [skip] {key}: {type(e).__name__}: {str(e)[:80]}")
            continue
        t0 = time.time()
        frag_cache = {}
        for r in df.itertuples():
            ids = tok.encode(r.text)
            nfrag = 0
            for i in ids:
                if i not in frag_cache:
                    frag_cache[i] = tok.is_fragment(i)
                nfrag += frag_cache[i]
            rows.append(dict(tokenizer=key, lang=r.lang, sent_id=r.sent_id, tokens=len(ids),
                             fragments=nfrag, words=words(r.text), chars=len(r.text),
                             bytes=len(r.text.encode("utf-8")),
                             roundtrip=(tok.decode(ids) == r.text)))
        meta.append(dict(tokenizer=key, vocab_size=tok.vocab_size, seconds=round(time.time() - t0, 1)))
        print(f"  {key:14s} vocab={tok.vocab_size:>7,}  {time.time()-t0:5.1f}s")
    return pd.DataFrame(rows), pd.DataFrame(meta)

if __name__ == "__main__":
    which = sys.argv[1] if len(sys.argv) > 1 else "pretrained"
    norm = sys.argv[2] if len(sys.argv) > 2 else "nfc"
    keys = [t["key"] for t in (C.TOKENIZERS if which == "pretrained" else C.OWN_TOKENIZERS)]
    C.RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    counts, meta = run(keys, norm)
    sfx = which if norm == "nfc" else f"{which}_raw"
    counts.to_csv(C.RESULTS_DIR / f"sentence_counts_{sfx}.csv", index=False)
    meta.to_csv(C.RESULTS_DIR / f"tokenizer_meta_{sfx}.csv", index=False)
    print(f"saved {len(counts):,} rows; round-trip exact: {counts.roundtrip.mean():.4%}")
