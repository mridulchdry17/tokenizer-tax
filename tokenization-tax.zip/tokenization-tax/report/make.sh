#!/usr/bin/env bash
# two-pass build: docx -> pdf -> page numbers -> docx -> pdf
set -e; cd "$(dirname "$0")"
N=Minor_Project_Report_Mridul_Chaudhary
for pass in 1 2 3; do
  node build.js >/dev/null
  soffice --headless --convert-to pdf $N.docx >/dev/null 2>&1
  cp pages.json prev.json 2>/dev/null || true
  python3 paginate.py $N.pdf
  if cmp -s pages.json prev.json; then echo "stable after pass $pass"; break; fi
done
zip -d $N.docx '*/' >/dev/null 2>&1 || true
