// Builds Minor_Project_Report_Mridul.docx. Run twice: pass 1 writes the file,
// paginate.py reads page numbers from the PDF into pages.json, pass 2 fills TOC.
const fs = require("fs");
const path = require("path");
const L = require("./lib");
const { D, P, C, blank, chapter, frontTitle, h2, h3, bullet, numbered, figure, figureId, tableCaption, table,
  equation, code, tocLine, FIGS, TABS, HEADS, NUMREFS, FONT, BODY } = L;
const { Document, Packer, Paragraph, TextRun, ImageRun, AlignmentType, Footer, PageNumber, NumberFormat,
  LevelFormat, PageBreak } = D;

const ROOT = path.resolve(__dirname, "..");
const FIG = (f) => path.join(ROOT, "figures", f);
const data = JSON.parse(fs.readFileSync(path.join(__dirname, "data.json"), "utf8"));
const pages = fs.existsSync(path.join(__dirname, "pages.json")) ? JSON.parse(fs.readFileSync(path.join(__dirname, "pages.json"))) : {};
const pg = (k) => pages[k] ?? "0";

const STUDENT = "Mridul Chaudhary", ENROL = "04115611923", SECTION = "F-12";
const SUPERVISOR = "____________________", DESIGNATION = "Assistant Professor";
const TITLE = "THE TOKENIZATION TAX: MEASURING THE COST OF INDIAN LANGUAGES IN OPEN SMALL LANGUAGE MODELS";
const TITLE_CASE = "The Tokenization Tax: Measuring the Cost of Indian Languages in Open Small Language Models";

// ------------------------------------------------------------------ cover
function cover() {
  const logo = fs.readFileSync(path.join(__dirname, "logo.jpg"));
  const t = (text, size, bold, o = {}) => new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: o.after ?? 80, line: 276 },
    children: [new TextRun({ text, font: FONT, size, bold })] });
  const kv = (a, b) => new Paragraph({ spacing: { after: 100 }, tabStops: [{ type: "left", position: 4300 }],
    children: [new TextRun({ text: a, font: FONT, size: 22 }), new TextRun({ text: "\t" + b, font: FONT, size: 22 })] });
  return [
    ...blank(1),
    t(TITLE, 36, true, { after: 280 }),
    t("MINOR PROJECT REPORT", 24, true, { after: 200 }),
    t("SUBMITTED IN PARTIAL FULFILMENT OF THE REQUIREMENTS FOR THE AWARD", 20, false, { after: 0 }),
    t("OF THE DEGREE OF", 20, false),
    t("BACHELOR OF TECHNOLOGY", 26, true, { after: 40 }),
    t("(ARTIFICIAL INTELLIGENCE AND DATA SCIENCE)", 22, true, { after: 200 }),
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 240 },
      children: [new ImageRun({ data: logo, type: "jpg", transformation: { width: 200, height: 104 },
        altText: { title: "Institute logo", description: "ADGIPS logo", name: "logo" } })] }),
    kv(`Submitted by: ${STUDENT}`, `University Enrolment / Roll No.: ${ENROL}`),
    kv(`Section: ${SECTION}`, "Semester: Seventh"),
    new Paragraph({ spacing: { after: 100 }, children: [new TextRun({ text: `Under the Supervision of: ${SUPERVISOR}`, font: FONT, size: 22 })] }),
    new Paragraph({ spacing: { after: 300 }, children: [new TextRun({ text: `Designation: ${DESIGNATION}`, font: FONT, size: 22 })] }),
    t("Academic Session: 2026–2027", 22, false, { after: 240 }),
    t("DEPARTMENT OF ARTIFICIAL INTELLIGENCE AND DATA SCIENCE", 22, true, { after: 40 }),
    t("DR. AKHILESH DAS GUPTA INSTITUTE OF PROFESSIONAL STUDIES", 22, true, { after: 40 }),
    t("F-26, 0-Pusta Road, Shastri Park, Shahdara, Delhi – 110053", 20, false, { after: 20 }),
    t("Affiliated to Guru Gobind Singh Indraprastha University, Delhi", 20, false, { after: 20 }),
    t("Year of Submission: 2026", 20, false),
  ];
}

// ------------------------------------------------------------------ front matter
function front() {
  const out = [];
  out.push(frontTitle("DECLARATION BY THE STUDENT"));
  out.push(P(`I, ${STUDENT}, a student of Bachelor of Technology (Artificial Intelligence and Data Science), Department of Artificial Intelligence and Data Science, Dr. Akhilesh Das Gupta Institute of Professional Studies, bearing University Enrolment No. ${ENROL}, hereby declare that the Minor Project Report entitled “${TITLE_CASE}” is my original work carried out as part of the prescribed academic requirements.`));
  out.push(P("I have duly acknowledged all sources, publications, datasets, software libraries, models and other materials used in preparing this report. No part of this report has been presented as the work of another person without appropriate attribution. The report has not been submitted previously for the award of another degree or diploma, except where explicitly disclosed."));
  out.push(...blank(3));
  out.push(P("Student Signature: ____________________", { align: AlignmentType.LEFT }));
  out.push(P(`Student Name: ${STUDENT}          Enrolment No.: ${ENROL}`, { align: AlignmentType.LEFT }));
  out.push(P("Date: ____/____/________          Place: Delhi", { align: AlignmentType.LEFT }));

  out.push(frontTitle("CERTIFICATE BY THE SUPERVISOR"));
  out.push(P(`This is to certify that the Minor Project Report entitled “${TITLE_CASE}”, submitted by ${STUDENT} (University Enrolment No. ${ENROL}), in partial fulfilment of the requirements for the award of the degree of Bachelor of Technology (Artificial Intelligence and Data Science) of Guru Gobind Singh Indraprastha University, Delhi, is a record of project work carried out under my guidance and supervision at Dr. Akhilesh Das Gupta Institute of Professional Studies, Delhi.`));
  out.push(P("To the best of my knowledge, the work presented in this report is original, and the student has acknowledged relevant sources appropriately. The report is recommended for evaluation as a Minor Project."));
  out.push(...blank(3));
  out.push(P(`Name and Signature of Supervisor: ____________________`, { align: AlignmentType.LEFT }));
  out.push(P(SUPERVISOR, { align: AlignmentType.LEFT, after: 0 }));
  out.push(P(`Designation: ${DESIGNATION}`, { align: AlignmentType.LEFT, after: 0 }));
  out.push(P("Department of Artificial Intelligence and Data Science", { align: AlignmentType.LEFT, after: 0 }));
  out.push(P("Dr. Akhilesh Das Gupta Institute of Professional Studies, Delhi", { align: AlignmentType.LEFT, after: 0 }));
  out.push(P("Date: ____/____/________", { align: AlignmentType.LEFT }));

  out.push(frontTitle("ABSTRACT"));
  out.push(P("Language models do not read words; they read tokens, and every token costs money on a hosted API and memory and time on a laptop. A tokenizer built mostly from English text splits Indian-language words into many small pieces, so the same message can need several times more tokens in Hindi, Tamil or Odia than in English. This project measures that “tokenization tax” for the tokenizers of free, open small language models that run on an ordinary laptop such as an Apple M5 MacBook — Qwen2.5/Qwen3, Llama 3.2, Gemma 2, Gemma 3, Mistral (Tekken) and TinyLlama/Llama 2 — with GPT-4o’s o200k tokenizer as a commercial reference."));
  out.push(P("The study uses FLORES-200, a corpus in which the same 1,012 sentences are professionally translated into every language, so token counts can be compared directly. English and 22 Indian languages (12 major languages in the main analysis and 10 more in an extended set) were tokenized with 8 tokenizers, giving 186,208 sentence-level measurements. For each pair the study reports tokens per word, the premium over English with 95% bootstrap confidence intervals, sub-character fragments, cost at a fixed token price and context-window capacity. A controlled experiment then trains three tokenizers that are identical except for the language mix of their training text."));
  out.push(P("Every one of the 84 tokenizer–language pairs in the main set costs more than English: 60 cost more than twice as much and 27 more than five times. The tax varies by an order of magnitude between models. Gemma 3 has the lowest mean premium (1.87×; 1.21× for Bengali, 3.50× for Odia), followed by GPT-4o (2.17×). Qwen2.5/Qwen3 (6.13×), Llama 3.2 (6.83×) and TinyLlama (7.10×) — the small models most often run on laptops — need six to seven times as many tokens; with Llama 3.2 an 8,192-token window holds about 6,600 English-equivalent words of English but only about 860 of Tamil and 540 of Odia. The tax is explained by sub-character fragments (Spearman ρ = 0.79 between fragment share and premium) and not by the size of the text in bytes (ρ = 0.21). In the controlled experiment, an English-only tokenizer gives a 10.0× premium, adding 10% Indian text cuts it to 3.0×, and a balanced mix to 1.9×, at the price of 47% more tokens for English. The project concludes that the tax is a design choice of the tokenizer, not a property of Indian languages, and that the choice of model alone can change the cost of serving an Indian user by a factor of three to seven."));
  out.push(P("**Keywords:** tokenization, byte-pair encoding, multilingual fairness, Indian languages, small language models, FLORES-200, context window, inference cost.", { align: AlignmentType.LEFT }));

  out.push(frontTitle("ACKNOWLEDGEMENT"));
  out.push(P("I express my sincere gratitude to Dr. Akhilesh Das Gupta Institute of Professional Studies, Delhi, and the Department of Artificial Intelligence and Data Science for providing the academic environment and facilities necessary to complete this Minor Project."));
  out.push(P(`I am especially thankful to my supervisor for valuable guidance, constructive feedback and continuous support throughout the project. I also thank the faculty members, laboratory staff and all others who contributed to the successful completion of this work.`));
  out.push(P("I acknowledge the creators of the FLORES-200 benchmark and of the open models and libraries used in this project, in particular the Qwen, Llama, Gemma, Mistral and TinyLlama teams, Hugging Face Tokenizers, tiktoken, pandas, SciPy and matplotlib, and A. Petrov and co-authors for their public mirror of FLORES-200. An AI assistant (Claude, Anthropic) was used to help write the analysis code, run the experiments and draft parts of this report; I have reviewed, edited and verified all content, including every result."));
  out.push(P("Finally, I thank my family and friends for their encouragement and support."));
  out.push(...blank(2));
  out.push(P(STUDENT, { align: AlignmentType.RIGHT }));
  return out;
}

// ------------------------------------------------------------------ lists + TOC (filled after pass 1)
function lists() {
  const out = [];
  out.push(frontTitle("LIST OF FIGURES"));
  FIGS_FINAL.forEach(f => out.push(tocLine(`${f.id}: ${f.caption}`, pg(f.id), 1)));
  out.push(frontTitle("LIST OF TABLES"));
  TABS_FINAL.forEach(t => out.push(tocLine(`${t.id}: ${t.caption}`, pg(t.id), 1)));
  out.push(frontTitle("LIST OF ABBREVIATIONS / NOTATIONS"));
  const ab = [
    ["AI", "Artificial Intelligence"], ["API", "Application Programming Interface"], ["BPE", "Byte-Pair Encoding"],
    ["CI", "Confidence Interval (95%, bootstrap)"], ["CPU / GPU", "Central / Graphics Processing Unit"], ["CSV", "Comma-Separated Values"],
    ["DFD", "Data Flow Diagram"], ["FLORES", "Facebook Low Resource (MT benchmark), 200-language version"], ["FR / NFR", "Functional / Non-Functional Requirement"],
    ["IEEE", "Institute of Electrical and Electronics Engineers"], ["LLM / SLM", "Large / Small Language Model"], ["MLX", "Apple’s machine-learning framework for Apple silicon"],
    ["NFC", "Unicode Normalization Form C (canonical composition)"], ["NLP", "Natural Language Processing"], ["SP", "SentencePiece"],
    ["UML", "Unified Modelling Language"], ["USD", "United States Dollar"], ["UTF-8", "8-bit Unicode Transformation Format"],
    ["F(L,T)", "Fertility: tokens per word of language L under tokenizer T"], ["P(L,T)", "Token premium of L relative to English under T"],
    ["Φ(L,T)", "Share of tokens that are sub-character fragments"], ["W", "Context window size in tokens"], ["ρ", "Spearman rank correlation"],
  ];
  out.push(table(["Abbreviation / Symbol", "Full Form / Meaning"], ab, [2600, 6426], { size: 22, leftCols: [1] }));
  out.push(frontTitle("TABLE OF CONTENTS"));
  HEADS_FINAL.filter(h => !["TABLE OF CONTENTS"].includes(h.text)).forEach(h => out.push(tocLine(h.text, pg("H:" + h.text), h.level)));
  return out;
}

// ------------------------------------------------------------------ chapters
const T = data.short;                 // short tokenizer names in table order
function body() {
  const o = [];
  // ===== Chapter 1
  o.push(chapter("Introduction"));
  o.push(h2("1.1 Introduction to the Project Domain"));
  o.push(P("Large language models (LLMs) such as GPT-4o, Llama, Qwen and Gemma have become general-purpose tools for writing, translation, question answering and customer support. Before a model can read text, a tokenizer cuts the text into tokens — whole words, pieces of words, single characters or even single bytes — and maps each one to a number in a fixed vocabulary [6], [7], [9]. Everything the model does is counted in these tokens. Hosted APIs charge per token [24]; the context window, the amount of text a model can consider at once, is a fixed number of tokens; and on a local machine the time and memory needed to process a prompt grow with its length in tokens, the attention part even quadratically [31]."));
  o.push(P("Tokenizers are learned from a training corpus, and the most common pieces of that corpus become single tokens. Because public web text is dominated by English, an English word like “funeral” is usually one token, while a Hindi or Tamil word with the same meaning may be split into many pieces. The same idea therefore costs a different number of tokens depending on the language in which it is written (Table 1.1). Earlier studies called this a premium or unfairness between languages [1], [2]. This report calls it the **tokenization tax**."));
  const ex = data.examples;
  const exKeys = ["gemma3", "gpt4o", "gemma2", "mistral_nemo", "qwen2_5", "llama3_2", "llama2"];
  o.push(tableCaption("Number of tokens for the same FLORES sentence (no. 59, “Over four million people went to Rome to attend the funeral.”) in four languages"));
  o.push(table(["Tokenizer", "English", "Hindi", "Tamil", "Odia"],
    exKeys.map((k, i) => [T[data.order.indexOf(k)], ...["eng_Latn", "hin_Deva", "tam_Taml", "ory_Orya"].map(l => ex[l].tok[k].n)]),
    [3000, 1500, 1500, 1500, 1500]));
  o.push(P("The question matters for India. The Eighth Schedule of the Constitution lists 22 languages [32], and most Indians are more comfortable in one of them than in English. If a model needs five times as many tokens for Odia, an Odia user pays five times as much for the same service, waits longer for an answer and can fit only a fifth as much of a document into the model’s memory.", { before: 120 }));

  o.push(h2("1.2 Background and Motivation"));
  o.push(P("Two developments make the question timely. First, small open models with one to four billion parameters (Qwen2.5-0.5B to 3B, Qwen3-0.6B to 4B, Llama 3.2-1B and 3B, Gemma 3-1B and 4B, TinyLlama-1.1B) now run comfortably on a student laptop. An Apple M5 MacBook can run them through the MLX framework [27] or a tool such as Ollama, with no internet connection and no API bill. For these models the “price” of a token is paid in seconds and in unified memory instead of rupees, but the tax is the same: more tokens mean slower answers and a context window that fills up sooner."));
  o.push(P("Second, Indian organisations have started to build their own models. Sarvam-1 [13] is a 2-billion-parameter model trained with a tokenizer designed for ten Indian languages, and IndicBERT v2 [12] is an encoder trained on 23 Indian languages. Their builders argue that a well-designed tokenizer is the first step to fair support. This project tests that idea on the small models that a student, start-up or government office in India is most likely to download first, and asks how large the tax is, why it arises and whether it can be removed."));

  o.push(h2("1.3 Problem Statement"));
  o.push(P("Given the same content in English and in Indian languages, measure how many tokens the tokenizers of popular free and open small language models need for each language; express the difference as a premium over English, as a cost per 1,000 words and as usable context-window capacity; explain which properties of a tokenizer cause the difference; and show experimentally whether the language mix of the tokenizer’s training data is responsible. The measurement must use professionally translated parallel text, report uncertainty, be fully reproducible on a laptop CPU and be extendable to any new model with one line of configuration."));

  o.push(h2("1.4 Objectives of the Project"));
  o.push(...numbered([
    "To build a reproducible pipeline that loads the FLORES-200 parallel corpus for English and 22 Indian languages and checks that all languages are sentence-aligned.",
    "To tokenize every sentence with the tokenizers of free, open small models that run on an Apple-silicon laptop (Qwen2.5/Qwen3, Llama 3.2, Gemma 2, Gemma 3, Mistral Tekken, TinyLlama/Llama 2), with GPT-4o’s o200k tokenizer as a commercial reference, and with India-built tokenizers (Sarvam-1, IndicBERT v2) integrated through configuration.",
    "To compute tokens per word, the token premium relative to English with 95% confidence intervals, the cost per 1,000 words at a fixed token price and the number of English-equivalent words that fit in common context windows.",
    "To explain the differences by measuring how often a tokenizer breaks a single character into byte fragments, and by comparing this with the size of the text in bytes.",
    "To run a controlled experiment that trains three tokenizers with the same algorithm and vocabulary size but different language mixes, and to measure the effect of the mix on the tax.",
  ]));

  o.push(h2("1.5 Scope of the Project"));
  o.push(P("The project measures tokenizers, not the full models: token counts depend only on the tokenizer, so they can be measured exactly and quickly without downloading model weights. It does not measure translation or answer quality. The main analysis covers 12 major Indian languages (Hindi, Bengali, Marathi, Telugu, Tamil, Urdu, Gujarati, Kannada, Malayalam, Odia, Punjabi and Assamese); 10 further languages and dialects (Maithili, Sanskrit, Nepali, Sindhi, Kashmiri, Manipuri, Santali, Bhojpuri, Awadhi and Magahi) are reported in an extended set. Costs are illustrated with a single list price per token; latency on Apple silicon is supported by an optional script (Section 4.8) but is not part of the reported results. The two India-built tokenizers could not be downloaded in the environment in which the experiments were run (Section 5.7); the code measures them automatically when run with internet access."));

  o.push(h2("1.6 Organisation of the Report"));
  o.push(P("Chapter 2 reviews related work, identifies the limitations of existing studies and lists the requirements of the system. Chapter 3 presents the design: architecture, data flow, dataset, the metrics and their formulae, and the tokenizers chosen. Chapter 4 describes the implementation, the 26 automated tests and deployment on a laptop. Chapter 5 reports and discusses all results, including the controlled experiment. Chapter 6 concludes and outlines future work. The appendices give installation details, sample input and output, key source code and additional results."));

  // ===== Chapter 2
  o.push(chapter("Requirement Analysis and System Specification"));
  o.push(h2("2.1 Introduction"));
  o.push(P("This chapter places the project in the context of earlier research on tokenization and multilingual fairness, explains what existing studies leave open for Indian users of small open models, and specifies what the proposed system must do and what it needs to run."));
  o.push(h2("2.2 Literature Review and Related Work"));
  o.push(h3("2.2.1 Subword tokenization"));
  o.push(P("Modern language models use subword tokenizers that sit between characters and words. Byte-Pair Encoding (BPE) starts from single symbols and repeatedly merges the most frequent adjacent pair until the vocabulary reaches a chosen size [6]. GPT-2 introduced byte-level BPE, which starts from the 256 possible bytes so that any text can be encoded without an “unknown” token [9]; GPT-4o, Llama 3, Qwen and Mistral use this design. SentencePiece [7] treats text as a raw stream of Unicode characters and learns BPE or unigram pieces [8]; it falls back to bytes only for characters it has never seen. Gemma and Llama 2 use SentencePiece. WordPiece [10], used by BERT-style encoders such as IndicBERT, is similar to BPE but chooses merges by likelihood. In all three, frequent strings become single tokens, so the composition of the training corpus decides which languages are encoded efficiently."));
  o.push(h3("2.2.2 Tokenization and multilingual performance"));
  o.push(P("Rust et al. [3] showed that the quality of a multilingual model’s tokenizer for a given language, measured by fertility (tokens per word) and the proportion of words that are split, predicts how well the model performs on that language. Velayuthan and Sarveswaran [33] found that popular tokenizers handle complex scripts such as Tamil, Sinhala and Hindi poorly and that standard pre-tokenization rules split them in unhelpful places."));
  o.push(h3("2.2.3 The cost of languages"));
  o.push(P("Petrov et al. [1] measured the tokenizers of 17 models on FLORES-200 and found that the same text can need up to 15 times more tokens in some languages than in English, with consequences for cost, latency and context length. Ahia et al. [2] studied commercial APIs and found that speakers of many languages pay more for the same content while receiving lower quality, and that the extra cost falls hardest on languages of lower-income countries. Both studies cover hundreds of languages but only a few of the newest small open models, report Indian languages only as part of a global picture, and do not test what happens when the tokenizer’s training mix is changed in a controlled way."));
  o.push(h3("2.2.4 Indian-language models and benchmarks"));
  o.push(P("IndicNLPSuite [11] and IndicBERT v2 [12] built large monolingual corpora and encoder models for Indian languages. Sarvam-1 [13] is a decoder model whose tokenizer was designed for ten Indian languages; its builders report much lower fertility for Indian languages than for other open models. FLORES-101 [5] and its successor FLORES-200 from the No Language Left Behind project [4] provide the same 3,001 English sentences (from Wikinews, Wikivoyage and Wikibooks) professionally translated into each language, which makes exact cross-language comparison possible. Table 2.1 summarises the approaches."));
  o.push(tableCaption("Comparison of existing studies with this project"));
  o.push(table(["Study", "Corpus", "Tokenizers", "Indian focus", "Controlled mix", "Main gap"], [
    ["Rust et al. [3]", "Mono-lingual", "mBERT, mono BERTs", "No", "No", "Encoders only"],
    ["Petrov et al. [1]", "FLORES-200", "17 (2023 models)", "Part of 200", "No", "Few current SLMs"],
    ["Ahia et al. [2]", "FLORES, others", "Commercial APIs", "Part of 22+", "No", "Closed models"],
    ["Velayuthan et al. [33]", "Various", "Popular tokenizers", "Tamil, Hindi", "Partly", "Few languages"],
    ["Sarvam-1 [13]", "Own", "Sarvam-1", "Yes (10)", "No", "Self-reported"],
    ["This project", "FLORES-200", "8 open/ref. + 3 own", "Yes (22)", "Yes", "Tokens, not quality"],
  ], [1700, 1300, 1700, 1250, 1200, 1876], { size: 19 }));

  o.push(h2("2.3 Limitations of Existing Systems"));
  ["Most studies focus on hosted commercial models; little is known about the small open models that Indian students and start-ups actually run locally, such as Qwen2.5-0.5B, Llama 3.2-1B or Gemma 3-1B.",
    "Results are usually given as a single ratio per language, without confidence intervals, without translating the ratio into context-window capacity, and without separating tokenizers that share the same vocabulary.",
    "The cause of the tax is usually explained informally (“less training data”) and has rarely been tested by changing only the data mix while keeping everything else fixed.",
    "Unicode normalisation is rarely controlled, although Indian scripts can be stored in more than one equivalent byte sequence.",
    "Many studies are hard to reproduce: they depend on large downloads, GPUs or paid API calls."].forEach(t => o.push(bullet(t)));

  o.push(h2("2.4 Proposed System and Requirements"));
  o.push(P("The proposed system is a five-phase, script-based pipeline (Figure 3.1): (1) data preparation, (2) tokenization, (3) a controlled tokenizer-training experiment, (4) analysis and (5) figures, examples and tests. It addresses the limitations above by focusing on open small models, by computing bootstrap confidence intervals and practical metrics, by measuring sub-character fragments, by training its own tokenizers under controlled conditions, by normalising text to NFC (with an ablation on raw text) and by running end-to-end on a laptop CPU in under two minutes."));
  o.push(h2("2.5 Functional Requirements"));
  o.push(tableCaption("Functional requirements"));
  o.push(table(["ID", "Requirement"], [
    ["FR1", "Load FLORES-200 devtest and dev files for English and 22 Indian languages; verify that every language has the same number of sentences."],
    ["FR2", "Load any tokenizer either from a local tokenizer.json or from the Hugging Face Hub by repository name, through one configuration entry."],
    ["FR3", "Encode every sentence without special tokens (BOS/EOS) and record tokens, words, characters, UTF-8 bytes and sub-character fragments."],
    ["FR4", "Verify that decoding the tokens reproduces the (normalised) input exactly."],
    ["FR5", "Compute fertility, premium vs English with 95% paired bootstrap CIs, cost per 1,000 words and context capacity for each tokenizer–language pair."],
    ["FR6", "Train three BPE tokenizers with identical settings but different language mixes, using only the dev split."],
    ["FR7", "Produce all tables and figures automatically, and run an automated test suite."],
    ["FR8", "Optionally measure prompt-processing time of local models on Apple silicon."],
  ], [900, 8126], { leftCols: [1] }));
  o.push(h2("2.6 Non-Functional Requirements"));
  o.push(tableCaption("Non-functional requirements"));
  o.push(table(["ID", "Category", "Requirement"], [
    ["NFR1", "Performance", "Full study ≤ 5 minutes on a 4-core laptop CPU; no GPU needed."],
    ["NFR2", "Validity", "Parallel text only; own tokenizers never see a test sentence; English is the fixed reference."],
    ["NFR3", "Reproducibility", "All randomness seeded (seed 42); all settings in config.py; every result regenerated by run_all.sh."],
    ["NFR4", "Accuracy", "Token counts identical to the official libraries (checked against OpenAI’s tiktoken ranks)."],
    ["NFR5", "Portability", "Runs on macOS (Apple silicon), Linux and Windows with Python ≥ 3.10."],
    ["NFR6", "Extensibility", "A new tokenizer or language is added with one line in config.py."],
    ["NFR7", "Cost", "Only free and openly licensed data, models and software."],
  ], [900, 1700, 6426], { leftCols: [2] }));
  o.push(h2("2.7 Hardware and Software Requirements"));
  o.push(tableCaption("Hardware requirements (minimum, as used, and target)"));
  o.push(table(["Component", "Minimum", "Used for the reported results", "Target for local models"], [
    ["Processor", "2-core x86-64 or ARM", "4-core x86-64 virtual machine", "Apple M5 (MacBook)"],
    ["GPU", "Not required", "Not used", "M5 integrated GPU via MLX (optional)"],
    ["Memory", "4 GB RAM", "≈ 3.8 GB RAM", "16 GB unified memory"],
    ["Storage", "1 GB free", "≈ 0.4 GB (data, tokenizers, results)", "+ 0.3–3 GB per 4-bit model"],
  ], [1700, 2000, 2700, 2626], { size: 19 }));
  o.push(tableCaption("Software requirements"));
  o.push(table(["Software", "Version", "Purpose"], [
    ["Python", "3.10.12", "Implementation language"],
    ["Hugging Face Tokenizers", "0.23.3", "Loading and running all tokenizers; training own BPE"],
    ["pandas / NumPy", "2.3.3 / 2.2.6", "Data handling, aggregation, bootstrap"],
    ["SciPy", "1.15.3", "Spearman correlation, geometric mean"],
    ["matplotlib", "3.10.9", "Figures"],
    ["pytest", "9.2.0", "Automated tests"],
    ["Node.js + js-tiktoken", "22 / 1.0.21", "Independent cross-check of GPT-4o counts"],
    ["Graphviz", "2.43", "Architecture, DFD and activity diagrams"],
    ["mlx-lm (optional)", "≥ 0.20", "Running small models on Apple silicon"],
    ["Operating system", "Ubuntu 22.04 (experiments); macOS (target)", "Development and deployment platform"],
  ], [2600, 2600, 3826], { leftCols: [2] }));
  o.push(h2("2.8 Feasibility Analysis"));
  ["**Technical feasibility:** token counting needs only the tokenizer file (2–33 MB), not the model weights; all 186,208 measurements take about 15 seconds on a laptop CPU.",
    "**Economic feasibility:** FLORES-200 is released under CC BY-SA 4.0, all tokenizers are freely downloadable and all libraries are open source. No API calls are needed; GPT-4o’s price is used only as an illustrative number.",
    "**Operational feasibility:** the pipeline is a sequence of command-line scripts driven by one configuration file; a new model is added by naming its Hugging Face repository.",
    "**Legal and ethical feasibility:** no personal data is processed. Llama 3.2 and Gemma tokenizers are subject to their model licences and are loaded from their public distribution; the project redistributes only derived counts."].forEach(t => o.push(bullet(t)));

  // ===== Chapter 3
  o.push(chapter("System Design"));
  o.push(h2("3.1 Proposed System Architecture"));
  o.push(P("Figure 3.1 shows the architecture. The only inputs are the FLORES-200 text files and the tokenizer files. Phase 1 prepares the data; Phase 2 tokenizes every sentence with every tokenizer; Phase 3 trains three tokenizers for the controlled experiment and feeds them back into Phase 2; Phase 4 computes all metrics, tables, figures and tests. An optional module runs real models on Apple silicon. Each phase is an independent Python script that communicates with the others only through files, so phases can be re-run separately."));
  o.push(...figure(FIG("fig3_arch.png"), "Proposed system architecture: the five-phase pipeline", 5.2));
  o.push(h2("3.2 Overall System Workflow"));
  o.push(P("Figure 3.2 is a Level-1 data flow diagram (DFD): external entities are rectangles, processes are ellipses and data stores are open boxes. Figure 3.3 details the per-sentence logic of the tokenization process as a UML activity diagram, and Figure 3.4 shows a complete run over time as a UML sequence diagram."));
  o.push(...figure(FIG("fig3_dfd.png"), "Level-1 data flow diagram of the system", 4.0));
  o.push(h2("3.3 Data Collection and Dataset Description"));
  o.push(P("**Source and licence.** FLORES-200 [4], [5] contains 3,001 English sentences from Wikinews, Wikivoyage and Wikibooks, each professionally translated into 200 languages and checked by a second translator. The public part is split into *dev* (997 sentences) and *devtest* (1,012 sentences). The files were obtained from a public GitHub mirror of the official release [30] because the official download server was not reachable from the build environment; the mirror contains the unmodified dev and devtest files."));
  o.push(P("**Language selection.** English is the reference. The main analysis uses the 12 Indian languages with the most speakers and an established digital presence, which together cover eight scripts. The extended set adds 10 scheduled languages and major Hindi-belt varieties, including Santali in its own Ol Chiki script and Kashmiri and Sindhi in Perso-Arabic script. Table 3.1 lists the main languages with the size of the devtest text."));
  o.push(tableCaption("Languages in the main analysis (FLORES-200 devtest, 1,012 sentences each)"));
  o.push(table(["FLORES code", "Language", "Script", "Words", "Characters", "Bytes vs English"],
    data.langs, [1500, 1500, 1500, 1400, 1500, 1626]));
  o.push(P("**Splits and leakage prevention.** All measurements use the devtest split. The dev split is used only to train the project’s own tokenizers in Phase 3, and the training script removes any dev sentence that also occurs in devtest (two short sentences did). Because the sentences are parallel, sentence *i* carries the same information in every language, which is what makes the token premium a fair comparison.", { before: 120 }));
  o.push(h2("3.4 Data Preprocessing and Feature Engineering"));
  o.push(h3("3.4.1 Unicode normalisation"));
  o.push(P("The same Indian-script text can be stored in different byte sequences: for example, a Devanagari letter with a nukta can be one code point or a base letter followed by a combining nukta. 3,641 of the 23,276 devtest sentences are not in Unicode Normalization Form C (NFC) [26]. Qwen’s tokenizer normalises to NFC by itself, while the others do not, which would give some tokenizers an unfair advantage. All text is therefore converted to NFC before tokenization, as most keyboards and applications do. An ablation on the raw text is reported in Section 5.3.6."));
  o.push(h3("3.4.2 Metrics and formulae"));
  o.push(P("Let x_i^L be sentence i in language L, n_T(x) the number of tokens that tokenizer T produces for x without special tokens, and w(x) the number of whitespace-separated words. Fertility is the average number of tokens per word:"));
  o.push(equation("F(L,T) = Σᵢ n_T(xᵢᴸ) / Σᵢ w(xᵢᴸ)"));
  o.push(P("Because word boundaries differ between languages (Tamil and Malayalam join many words that English writes separately), the main metric is the token premium, which compares the same content directly:"));
  o.push(equation("P(L,T) = Σᵢ n_T(xᵢᴸ) / Σᵢ n_T(xᵢᴱⁿᵍ)"));
  o.push(P("A 95% confidence interval for P is obtained with a paired bootstrap [25]: the 1,012 sentence indices are resampled with replacement 2,000 times, the same resample is used for L and English, and the 2.5th and 97.5th percentiles of the recomputed ratio are reported. The number of tokens per English-equivalent word, the cost of a fixed amount of content at a price c per token and the capacity of a context window of W tokens follow directly:"));
  o.push(equation("τ(L,T) = P(L,T) · F(Eng,T),   Cost = 10⁶ · τ · c,   Capacity = W / τ"));
  o.push(P("Here Cost is the price of processing 1 million English-equivalent words of content in language L, and Capacity is the number of English-equivalent words of content that fit in the window. Finally, a token is a sub-character fragment if it is a byte-fallback token (such as <0xE0>) or if decoding it on its own does not give a valid Unicode character; Φ(L,T) is the share of such tokens. A Devanagari character takes three bytes in UTF-8, so a byte-level tokenizer that has not learned a character must spend up to three tokens on it."));
  o.push(...figure(FIG("fig3_act.png"), "UML activity diagram of the per-sentence tokenization and aggregation process", 2.6));
  o.push(h3("3.4.3 Controlled tokenizer-training experiment"));
  o.push(P("To test whether the language mix of the training data causes the tax, three byte-level BPE tokenizers are trained with exactly the same algorithm, pre-tokenizer, NFC normaliser and vocabulary size (8,000), on corpora with the same number of sentences (985–988). Only the mix differs: **English-only** (988 English sentences), **web-skewed** (90% English sentences, the remaining 10% shared equally among the 12 Indian languages, similar to the dominance of English on the web) and **balanced** (76 parallel sentences in each of the 13 languages). All training text comes from the dev split; all evaluation uses devtest."));
  o.push(h2("3.5 Algorithm / Model Selection"));
  o.push(P("Tokenizers were chosen to represent the free, open small models that run on a 16 GB Apple-silicon laptop in 4-bit form, plus one widely used commercial reference (Table 3.2). Where several models share one tokenizer, a single entry represents them: Qwen2.5 and Qwen3 produce identical token counts on all 23,276 sentences (checked automatically), Phi-3-mini and TinyLlama use the 32,000-token Llama 2 vocabulary, and gpt-oss-20b uses an o200k-based vocabulary [23]. The two India-built tokenizers are part of the configuration and are measured whenever the Hugging Face Hub is reachable."));
  o.push(tableCaption("Tokenizers included in the study"));
  const sm = data.summary;
  o.push(table(["Tokenizer", "Models it represents", "Type", "Vocabulary", "Origin"], [
    [sm[1][0], "GPT-4o (reference); gpt-oss-20b", "Byte-level BPE", sm[1][2], "USA"],
    ["Qwen2.5 / Qwen3", "Qwen2.5-0.5B–3B; Qwen3-0.6B–4B", "Byte-level BPE", sm[4][2], "China"],
    ["Llama 3.2", "Llama-3.2-1B / 3B-Instruct", "Byte-level BPE", sm[5][2], "USA"],
    ["Mistral (Tekken)", "Mistral-NeMo-12B; Ministral-8B", "Byte-level BPE", sm[3][2], "France"],
    ["Gemma 2", "Gemma-2-2B-it", "SentencePiece", sm[2][2], "USA"],
    ["Gemma 3", "Gemma-3-1B / 4B-it", "SentencePiece", sm[0][2], "USA"],
    ["TinyLlama / Llama 2", "TinyLlama-1.1B; Phi-3-mini", "SentencePiece", sm[6][2], "USA"],
    ["Sarvam-1*", "Sarvam-1 (2B)", "SentencePiece", "see card", "India"],
    ["IndicBERT v2*", "IndicBERT-v2 (encoder)", "WordPiece", "see card", "India"],
    ["Own BPE (×3)", "Controlled experiment", "Byte-level BPE", "8,000", "This project"],
  ], [1800, 2650, 1500, 1450, 1626], { size: 19 }));
  o.push(P("* Integrated in the configuration; not measured in this report (Section 5.7). Their vocabulary sizes are read from the files when measured.", { run: { size: 20 } }));
  o.push(h2("3.6 Module and Interface Design"));
  o.push(P("The system consists of seven numbered scripts, a small helper module and a test suite (Table 3.3). Every script reads its settings from config.py. The user interface is the command line; run_all.sh runs the whole study."));
  o.push(tableCaption("Module specification"));
  o.push(table(["Module", "Input", "Output"], [
    ["01_prepare_data.py", "FLORES-200 text files", "flores_devtest.csv, flores_dev.csv"],
    ["02_tokenize.py", "CSV, tokenizer files / Hub", "sentence_counts_*.csv, tokenizer_meta_*.csv"],
    ["03_train_tokenizers.py", "flores_dev.csv", "own_tokenizers/*.json, training_summary.json"],
    ["04_analyse.py", "sentence counts", "per_language_*.csv, summary_*.csv, nfc_ablation.csv"],
    ["05_figures.py", "analysis CSVs", "figures/*.png"],
    ["06_examples.py", "devtest, tokenizers", "examples.json (token-by-token examples)"],
    ["07_m5_generation_benchmark.py", "devtest, MLX model", "m5_<model>.json (optional)"],
    ["tokenizer_utils.py", "tokenizer key", "uniform encode / decode / is_fragment"],
    ["tests/test_pipeline.py", "all results", "26 automated tests"],
  ], [2900, 2700, 3426], { leftCols: [1, 2], font: FONT, size: 19 }));
  o.push(h2("3.7 UML / DFD Diagrams"));
  o.push(P("The Level-1 DFD (Figure 3.2) and the activity diagram (Figure 3.3) were presented above. Figure 3.4 is a UML sequence diagram of one complete run, from the user starting run_all.sh to the final test report."));
  o.push(...figure(FIG("fig3_seq.png"), "UML sequence diagram of a complete pipeline run", 6.0));
  o.push(h2("3.8 Database Design"));
  o.push(P("The system stores its data in flat CSV and JSON files rather than a database server, which keeps it portable and easy to inspect. Table 3.4 gives the schema of the central data store."));
  o.push(tableCaption("Schema of sentence_counts_*.csv (one row per tokenizer × language × sentence)"));
  o.push(table(["Field", "Type", "Description"], [
    ["tokenizer", "string", "Tokenizer key from config.py, e.g. llama3_2"],
    ["lang", "string", "FLORES code, e.g. hin_Deva"],
    ["sent_id", "integer", "Index 0–1011 of the parallel sentence"],
    ["tokens", "integer", "Number of tokens, special tokens excluded"],
    ["fragments", "integer", "Tokens that are not a whole character"],
    ["words", "integer", "Whitespace-separated words"],
    ["chars, bytes", "integer", "Unicode code points; UTF-8 bytes"],
    ["roundtrip", "boolean", "decode(encode(x)) equals x"],
  ], [1900, 1300, 5826], { leftCols: [2] }));

  // ===== Chapter 4
  o.push(chapter("Implementation, Testing and Maintenance"));
  o.push(h2("4.1 Development Environment and Tools"));
  o.push(P("The system was implemented in Python 3.10 with the libraries listed in Table 2.5 and developed on an Ubuntu 22.04 machine with 4 CPU cores and about 4 GB of memory, the same class of resources as a modest laptop. No GPU was used. Version control used Git. Model tokenizers were obtained as tokenizer.json files; on a machine with internet access the same code downloads them from the Hugging Face Hub automatically."));
  o.push(h2("4.2 Implementation of Project Modules"));
  o.push(h3("4.2.1 Data preparation"));
  o.push(P("01_prepare_data.py reads the devtest and dev files of all 23 languages, builds one tidy table per split with the columns sent_id, lang, language, script and text, and asserts that every language has the same number of non-empty sentences (1,012 and 997). It also reports the overlap between the two splits."));
  o.push(h3("4.2.2 Tokenizer interface"));
  o.push(P("tokenizer_utils.py hides the differences between tokenizer formats behind one small class with encode, decode and is_fragment methods. A tokenizer is loaded from a local tokenizer.json if present, otherwise from the Hugging Face Hub with the Tokenizers library, and finally through the Transformers AutoTokenizer for models that ship only a SentencePiece model file. Special tokens such as <bos> are never added, so the counts reflect the text alone."));
  o.push(h3("4.2.3 Tokenization"));
  o.push(P("02_tokenize.py normalises each sentence to NFC, encodes it, counts fragments (with a cache per token id, since the same ids recur) and checks the round trip. The 8 pretrained tokenizers process all 23,276 sentences in about 12 seconds in total. The script can also be run on raw text for the normalisation ablation and on the project’s own tokenizers."));
  o.push(h3("4.2.4 Controlled experiment and analysis"));
  o.push(P("03_train_tokenizers.py builds the three corpora described in Section 3.4.3 with a fixed random seed and trains each with the Tokenizers BpeTrainer (byte-level alphabet, minimum frequency 1, vocabulary 8,000). 04_analyse.py aggregates the sentence counts per tokenizer and language, computes the metrics of Section 3.4.2 and the paired bootstrap, and writes per-language and summary tables. 05_figures.py and 06_examples.py produce the figures and the token-by-token examples."));
  o.push(h2("4.3 Algorithm / Model Implementation"));
  o.push(P("The core of the analysis is the paired bootstrap. One matrix of 2,000 × 1,012 random sentence indices is drawn once with seed 42 and reused for every tokenizer and language, so all intervals are computed on the same resamples and are directly comparable. The essential code is:"));
  o.push(...code([
    "boots = rng.integers(0, n, size=(N_BOOTSTRAP, n))   # same resamples everywhere",
    "t, e = tokens[lang], tokens['eng_Latn']            # per-sentence counts",
    "premium = t.sum() / e.sum()",
    "bs = t[boots].sum(1) / e[boots].sum(1)",
    "ci = np.percentile(bs, [2.5, 97.5])",
  ]));
  o.push(P("The fragment test decodes each token id on its own: byte-level tokens that hold only part of a multi-byte character decode to the Unicode replacement character U+FFFD, and SentencePiece byte-fallback tokens have names of the form <0xNN>. Both are counted as fragments."));
  o.push(h2("4.4 User Interface and System Integration"));
  o.push(P("The system is operated from the command line. A single command, ./run_all.sh, fetches FLORES-200 if needed and runs all phases and the tests. To add a model, a user appends one dictionary with a key, a label and a Hugging Face repository name to TOKENIZERS in config.py; to add a language, one tuple to MAIN_LANGS or EXTENDED_LANGS. The price per token and the context windows are also set in config.py."));
  o.push(h2("4.5 Testing Methodology"));
  o.push(P("Testing combined automated unit and integration tests written with pytest, an independent cross-check against a different implementation and manual inspection of token-by-token output. The tests check the data (alignment, no empty sentences), the tokenizers (exact round trip, no special tokens, counts equal to a fresh encoding), the formulae (premium, confidence intervals, context capacity) and the controlled design of the experiment (equal vocabulary and corpus size)."));
  o.push(h2("4.6 Test Cases and Test Results"));
  o.push(tableCaption("Test cases and outcomes (26 tests, all passed)"));
  o.push(table(["ID", "Test", "Expected outcome", "Result"], [
    ["T1", "All 23 languages aligned", "1,012 sentences each", "Pass"],
    ["T2", "No empty sentences", "All texts non-empty", "Pass"],
    ["T3", "Controlled experiment design", "Vocab = 8,000; corpus sizes within 13 sentences", "Pass"],
    ["T4", "Word counter", "5 words for a padded Hindi sentence", "Pass"],
    ["T5–T12", "Round trip, 8 tokenizers", "decode(encode(x)) = NFC(x) for every sentence", "Pass"],
    ["T13–T20", "Stored count = fresh encoding, 8 tokenizers", "Equal for a sample Hindi sentence", "Pass"],
    ["T21", "No special tokens added", "“a” encodes to 1 token", "Pass"],
    ["T22", "English premium", "Exactly 1.0 for every tokenizer", "Pass"],
    ["T23", "Premium formula", "Equal to ratio of sums for all 184 pairs", "Pass"],
    ["T24", "Bootstrap CI", "Lower ≤ estimate ≤ upper for all pairs", "Pass"],
    ["T25", "Context capacity", "Capacity × τ = window for 4 windows", "Pass"],
    ["T26", "GPT-4o vs official tiktoken", "Identical totals for 5 languages", "Pass"],
  ], [1000, 2900, 3926, 1200], { leftCols: [1, 2], size: 19 }));
  o.push(P("The console output of the test run is reproduced in Appendix B (Figure B.1).", { before: 120 }));
  o.push(h2("4.7 Validation and Performance Testing"));
  o.push(P("**Independent validation.** The GPT-4o counts produced through the Hugging Face Tokenizers library were compared with counts produced by js-tiktoken 1.0.21, a JavaScript port of OpenAI’s tiktoken that ships OpenAI’s own o200k_base merge table. Totals were identical for English (26,873 tokens), Hindi (42,247), Bengali (46,011), Tamil (53,195) and Odia (134,286). **Round trip.** After NFC normalisation, decoding reproduced the input exactly for all 186,208 tokenizer–sentence pairs. **Performance.** Tokenizing, analysing and plotting took 16.8 seconds of wall-clock time on 4 CPU cores; the complete study including the tokenizer training and tests runs in under two minutes, which satisfies NFR1."));
  o.push(h2("4.8 Maintenance and Deployment Considerations"));
  o.push(P("The project is designed to be run again as new models appear: tokenizers change with model families (Llama 2 to Llama 3, Gemma 2 to Gemma 3), and each new release can be added with one configuration line. For use on the target laptop, 07_m5_generation_benchmark.py loads a 4-bit model with Apple’s MLX framework [27] and measures how long the model takes to process the same 50 FLORES sentences in seven languages, so that the token premium can be translated into seconds on the M5. Suggested models are mlx-community/Qwen2.5-0.5B-Instruct-4bit, Llama-3.2-1B-Instruct-4bit and gemma-3-1b-it-4bit. The scripts have no state beyond their files, need no server and can be scheduled to re-run whenever config.py changes."));

  // ===== Chapter 5
  o.push(chapter("Results and Discussions"));
  o.push(h2("5.1 Experimental Setup"));
  o.push(tableCaption("Experimental configuration"));
  o.push(table(["Setting", "Value"], [
    ["Corpus", "FLORES-200 devtest, 1,012 parallel sentences per language"],
    ["Languages", "English + 12 major Indian (main) + 10 further (extended)"],
    ["Pretrained tokenizers measured", "8 (7 distinct; Qwen2.5 ≡ Qwen3)"],
    ["Measurements", "186,208 tokenizer–sentence pairs (pretrained) + 69,828 (own)"],
    ["Normalisation", "Unicode NFC (raw text in ablation)"],
    ["Special tokens", "Excluded"],
    ["Confidence intervals", "Paired bootstrap, 2,000 resamples, 95%, seed 42"],
    ["Illustrative price", "US$2.50 per 1M input tokens (GPT-4o standard rate) [24]"],
    ["Context windows", "4,096; 8,192; 32,768; 128,000 tokens"],
    ["Own tokenizers", "Byte-level BPE, vocab 8,000, 985–988 training sentences, dev split"],
  ], [3000, 6026], { leftCols: [1] }));
  o.push(h2("5.2 Implementation Results"));
  o.push(h3("5.2.1 A worked example"));
  o.push(P("Table 1.1 already showed the token counts for one sentence. The Hindi version, “अंतिम संस्कार में शामिल होने के लिए, चार मिलियन से ज़्यादा लोग रोम गए.”, needs 18 tokens with Gemma 3, where most words are single tokens, but 38 with Llama 3.2, which splits nearly every word into two or three pieces, and 71 with TinyLlama, which spends roughly one token per character and four on the cluster “ज़्य”. The English sentence needs 12 tokens with every tokenizer. The full token sequences are listed in Appendix B."));
  o.push(h3("5.2.2 Tokens per word"));
  o.push(P("English is encoded very similarly by all tokenizers: 1.23 to 1.27 tokens per word for the six modern tokenizers and 1.37 for the older 32k TinyLlama vocabulary (Table D.1). For the Indian languages the spread is far larger. Hindi needs 1.38 tokens per word with Gemma 3 and 4.76 with Qwen2.5/Qwen3; Malayalam needs 3.36 with Gemma 3 and 16.26 with Llama 3.2. Fertility is not comparable across languages, because Dravidian languages pack more meaning into a word, so the rest of this chapter uses the premium, which compares the same content."));
  o.push(h2("5.3 Performance Analysis"));
  o.push(h3("5.3.1 The token premium"));
  o.push(P("Table 5.2 and Figure 5.1 give the premium for every tokenizer and main language. Every one of the 84 values is above 1: there is no tokenizer for which any Indian language is as cheap as English. 60 of the 84 exceed 2× and 27 exceed 5×."));
  o.push(tableCaption("Token premium vs English (same content) for the 12 main languages, ordered from lowest to highest average"));
  o.push(table(["Language", ...T], data.premium, [1450, 1080, 1080, 1080, 1080, 1100, 1080, 1076], { boldLast: true, size: 18 }));
  o.push(...figure(FIG("fig5_1_premium_heatmap.png"), "Token premium for each tokenizer (rows) and main language (columns); colour on a log scale", 6.3));
  o.push(P("The averages divide the tokenizers into two groups (Figure 5.2). Gemma 3 (1.87×), GPT-4o (2.17×), Gemma 2 (2.93×) and Mistral’s Tekken (3.21×) need two to three times as many tokens as English on average. Qwen2.5/Qwen3 (6.13×), Llama 3.2 (6.83×) and TinyLlama (7.10×) need six to seven times as many. The second group contains three of the most popular families of small models for laptops. Mistral shows that an average can hide a bad case: it is close to GPT-4o for most languages but needs 12.9× for Odia."));
  o.push(...figure(FIG("fig5_2_premium_by_tokenizer.png"), "Mean premium over the 12 main languages (dot) and range from the cheapest to the most expensive language (bar)", 6.0));
  o.push(P("Across tokenizers, Urdu (mean 2.48×), Hindi (2.58×) and Marathi (2.81×) are the cheapest Indian languages and Odia (8.61×) is by far the most expensive, followed by Punjabi (5.31×) and Malayalam (5.23×). Hindi and Urdu have the largest web presence, and Devanagari is shared by Hindi, Marathi and Nepali, so tokens learned for one help the others. Odia has its own script with little web text, and is the most expensive language for every tokenizer."));
  o.push(h3("5.3.2 Uncertainty of the estimates"));
  o.push(P("Table 5.3 gives 95% confidence intervals for three representative tokenizers. The intervals are narrow — typically ±1% of the estimate — because each premium is based on 1,012 sentences with more than 20,000 words. All differences between tokenizers discussed in this chapter are therefore far larger than the sampling uncertainty."));
  o.push(tableCaption("Token premium with 95% paired-bootstrap confidence interval"));
  o.push(table(["Language", "Gemma 3", "GPT-4o", "Llama 3.2"], data.ci, [1900, 2370, 2370, 2386], { size: 19 }));
  o.push(h3("5.3.3 What the tax costs: money and context"));
  o.push(P("At a flat price of US$2.50 per million tokens, processing one million English-equivalent words costs US$3.1–3.4 in English with any of the tokenizers (Table 5.4, Figure 5.3). In Odia the same content costs US$10.8 with Gemma 3, US$15.3 with GPT-4o, US$30.6 with Qwen and US$37.8 with Llama 3.2; in Tamil it costs US$4.55 with Gemma 3 and US$23.7 with Llama 3.2. For a locally run model the same multipliers apply to the compute spent processing a prompt."));
  o.push(tableCaption("Cost of processing 1 million English-equivalent words of content (US$, at $2.50 per 1M tokens)"));
  o.push(table(["Tokenizer", ...data.ctx_langs], data.cost, [1900, 1180, 1180, 1180, 1180, 1200, 1206], { size: 19 }));
  o.push(...figure(FIG("fig5_4_cost.png"), "Cost per 1,000 English-equivalent words for four tokenizers across languages", 5.6));
  o.push(P("The context window is affected in the same way (Table 5.5, Figure 5.4). An 8,192-token window, typical for small local models, holds about 6,000–6,700 English-equivalent words of English text, depending on the tokenizer. With Llama 3.2 it holds only about 2,600 words’ worth of Hindi, 860 of Tamil and 540 of Odia — an Odia user can give the model about one twelfth of the document an English user can. With Gemma 3 the same window holds about 5,050 words of Hindi and 4,500 of Tamil."));
  o.push(tableCaption("English-equivalent words that fit in an 8,192-token context window"));
  o.push(table(["Tokenizer", ...data.ctx_langs], data.ctx8, [1900, 1180, 1180, 1180, 1180, 1200, 1206], { size: 19 }));
  o.push(...figure(FIG("fig5_3_context_capacity.png"), "Context capacity of an 8,192-token window in English-equivalent words, by tokenizer and language", 6.2));
  o.push(h3("5.3.4 Why the tax arises"));
  o.push(P("A common explanation is that Indian scripts simply take more bytes: a Devanagari or Tamil character needs three bytes in UTF-8 compared with one for a Latin letter, so the same sentence is 2.5 to 3.2 times larger in bytes (Table 3.1). Figure 5.5 (left) shows that this explains little. Pooled over all 84 pairs, the rank correlation between byte premium and token premium is only ρ = 0.21 (p = 0.058). Urdu, at only 1.75× the bytes of English, still costs 3.15× with Qwen, while Bengali, at 2.64× the bytes, costs only 1.21× with Gemma 3."));
  o.push(P("The share of sub-character fragments explains far more (Figure 5.5, right; ρ = 0.79, p < 10⁻¹⁸). In Qwen2.5/Qwen3 and Llama 3.2, 68% and 74% of all tokens in the main Indian languages are pieces of a single character: the tokenizer has learned so few Indian-script merges that it falls back to raw UTF-8 bytes. TinyLlama’s 32k vocabulary has learned individual characters but almost no longer pieces, so it spends about one token per character (43% fragments, from byte fallback for rarer characters). Gemma 2 and Gemma 3 produce almost no fragments (≤ 0.1%) and GPT-4o only 3.7%; they have learned whole syllables and common words. The tax is therefore a direct consequence of which pieces of Indian text the tokenizer learned during training."));
  o.push(...figure(FIG("fig5_5_why.png"), "Token premium against byte premium (left) and against the share of sub-character fragments (right), one point per tokenizer and main language", 6.3));
  o.push(P("Vocabulary size alone is also not the answer. Qwen’s vocabulary (151,665) is larger than Mistral’s (131,072) and Llama 3.2’s (128,256) is similar, yet Mistral’s premium is about half of theirs; Gemma 2 and Gemma 3 have similar vocabulary sizes (256,000 and 262,145) but Gemma 3 is 36% cheaper on average. What matters is how much of the vocabulary was spent on Indian scripts, which depends on the training mix."));
  o.push(h3("5.3.5 Controlled experiment: the training mix causes the tax"));
  o.push(P("Table 5.6 and Figure 5.6 show the three tokenizers that differ only in their training mix. The English-only tokenizer reproduces the worst behaviour of the pretrained models: a mean premium of 10.0× and 94% sub-character fragments, since it has never seen an Indian character. Giving just 10% of the training sentences to Indian languages cuts the premium to 3.0×, and a balanced mix cuts it to 1.9×, with fragments almost eliminated (0.3%). The gains also carry over to the extended languages that none of the three tokenizers saw during training (mean premium 9.1×, 3.7× and 2.4×), because they share scripts with the training languages."));
  o.push(tableCaption("Controlled experiment: premium and tokens per English-equivalent word for three tokenizers that differ only in their training mix"));
  o.push(table(["Language", "Prem. Eng-only", "Prem. skewed", "Prem. balanced", "τ Eng-only", "τ skewed", "τ balanced"],
    data.own, [1800, 1200, 1200, 1250, 1200, 1150, 1226], { boldLast: true, size: 19 }));
  o.push(...figure(FIG("fig5_6_controlled.png"), "Tokens per English-equivalent word for the three controlled tokenizers", 6.2));
  o.push(P("The experiment also shows the cost of fairness with a fixed vocabulary. English needs 1.60 tokens per word with the English-only tokenizer, 1.64 with the skewed one and 2.35 with the balanced one — 47% more — because the balanced tokenizer spends most of its 8,000 entries on the twelve other languages. The vocabulary is a shared budget: real multilingual tokenizers such as Gemma 3 avoid the trade-off largely by using a much larger vocabulary. Because the training corpora are small (about 1,000 sentences), the absolute values are higher than for real tokenizers trained on billions of words; the experiment demonstrates the direction and size of the effect of the mix, not production-quality tokenizers."));
  o.push(h3("5.3.6 Ablation: Unicode normalisation"));
  o.push(P("Running the pretrained tokenizers on the raw, un-normalised FLORES text changed token counts by 0.07% on average. For 40% of the tokenizer–language pairs raw text costs slightly more; the largest effect was for Mistral’s Tekken on Bengali (+5.5%), Manipuri (+4.0%) and Assamese (+3.6%), which use the Bengali script where decomposed characters are common. Qwen is unaffected because it normalises internally. Normalising text to NFC before sending it to a model is therefore a small but free saving for Bengali-script languages."));
  o.push(h3("5.3.7 Extended languages"));
  o.push(P("The extended set (Appendix D, Figure D.1) confirms the pattern and shows its extremes. The Hindi-belt languages written in Devanagari — Maithili, Bhojpuri, Awadhi, Magahi and Nepali — are about as cheap as Hindi, because they reuse its tokens. Santali in Ol Chiki script is the most expensive language in the study: 13.7× with GPT-4o and 12.7× with Llama 3.2, and 5.2× even with the Gemma tokenizers. A language with its own little-used script receives almost no tokens in any of these vocabularies."));
  o.push(h2("5.4 Evaluation Metrics"));
  ["**Token premium P** (main metric): how many times more tokens the same content needs compared with English; 1.0 means parity.",
    "**Fertility F:** tokens per word within one language; useful for a single language but not comparable across languages.",
    "**Sub-character fragment share Φ:** the proportion of tokens that are not a whole character; a diagnostic of how well a script is covered.",
    "**Cost per 1M English-equivalent words** at a fixed price per token: translates the premium into money.",
    "**Context capacity:** English-equivalent words that fit in a context window; translates the premium into usable memory.",
    "**Spearman ρ:** rank correlation used to test which property of a tokenizer explains the premium."].forEach(t => o.push(bullet(t)));
  o.push(h2("5.5 Comparison with Existing Approaches"));
  o.push(P("The results agree with the direction of earlier studies and extend them. Petrov et al. [1] reported premiums of a similar magnitude for the tokenizers available in 2023; this project shows that the problem persists in several 2024–2025 small models (Qwen2.5, Qwen3 and Llama 3.2), even though GPT-4o’s and Gemma’s newer vocabularies reduced it markedly. Ahia et al. [2] found that commercial APIs charge more for many languages; this project shows the same mechanism applies to free local models, where the charge is paid in time and context. Compared with both, the project adds confidence intervals, the context-capacity and fragment analyses, an NFC control and a controlled training experiment that isolates the data mix as the cause."));
  o.push(h2("5.6 Discussion and Interpretation"));
  o.push(P("Three findings stand out. First, the choice of model matters more than the choice of language: for Tamil, switching from Llama 3.2 to Gemma 3 cuts the token count by a factor of 5.2, which is larger than the difference between Tamil and English under Gemma 3. A developer serving Indian users can reduce cost and latency several-fold simply by choosing a model with a better tokenizer. Second, the tax is not a property of Indian languages: Gemma 3 encodes Bengali with only 21% more tokens than English, and the controlled experiment produces a large tax or almost none from the same algorithm depending only on the data mix. Third, a large tax hurts small models most: they usually have short context windows and run on limited memory, so a 7× premium turns an 8,192-token window into the equivalent of about 1,000 English words."));
  o.push(P("For a user of an M5 laptop the practical advice is to prefer Gemma 3 (1B or 4B) for Indian-language work among the small models measured here, to avoid Qwen2.5/Qwen3 and Llama 3.2 for long Indian-language documents, and to normalise text to NFC. India-built models such as Sarvam-1 are designed to remove the tax and should be compared with Gemma 3 using the same pipeline."));
  o.push(h2("5.7 Limitations of the Proposed System"));
  ["The India-built tokenizers (Sarvam-1, IndicBERT v2) could not be measured: the environment used for the experiments could not reach the Hugging Face Hub, and their tokenizers are not distributed elsewhere. They are fully integrated in config.py and are measured by running 02_tokenize.py on any machine with internet access.",
    "Token counts are a proxy for cost and latency; actual prices, prompt caching and hardware throughput vary, and output tokens (which are often more expensive) were not studied.",
    "Fewer tokens do not guarantee better answers. Model quality in each language was outside the scope of this project.",
    "FLORES-200 is formal, well-edited news and travel text. Informal chat, code-mixed Hinglish and romanised Indian text, which are common in practice, may behave differently.",
    "The project’s own tokenizers were trained on about 1,000 sentences, so their absolute numbers are not comparable with production tokenizers.",
    "Words are counted by whitespace, which is a rough unit for agglutinative languages; this affects fertility but not the premium."].forEach(t => o.push(bullet(t)));

  // ===== Chapter 6
  o.push(chapter("Conclusion and Future Scope"));
  o.push(h2("6.1 Conclusion"));
  o.push(P("This project measured the tokenization tax that Indian languages pay in the tokenizers of free, open small language models. Using professionally translated parallel text from FLORES-200 for English and 22 Indian languages and 186,208 measurements, it found that every tokenizer charges more for every Indian language than for English, and that the size of the charge depends mainly on the model. Gemma 3 (1.87× on average) and GPT-4o (2.17×) are close to fair for most major languages; Qwen2.5/Qwen3 (6.13×), Llama 3.2 (6.83×) and TinyLlama (7.10×) — popular choices for laptops — need six to seven times as many tokens, which shrinks the usable context of an 8,192-token window to under 1,000 English-equivalent words for Tamil and Odia with Llama 3.2. The cause is that these tokenizers learned too few pieces of Indian scripts and fall back to byte fragments, and a controlled experiment showed that changing only the training mix moves the premium from 10.0× to 1.9×. The tokenization tax is a design decision, and it can be reduced."));
  o.push(h2("6.2 Major Contributions and Achievements"));
  o.push(tableCaption("Objectives and achievements"));
  o.push(table(["Objective", "Achievement"], [
    ["1. Reproducible parallel-text pipeline", "23 languages × 1,012 sentences, alignment checked; full run < 2 min on CPU"],
    ["2. Tokenize with open SLM tokenizers", "8 tokenizers measured (7 distinct); India-built tokenizers integrated"],
    ["3. Premium, cost and context metrics", "Premium with 95% CIs, cost per 1M words, capacity for 4 window sizes"],
    ["4. Explain the differences", "Fragment share explains the premium (ρ = 0.79); byte size does not (ρ = 0.21)"],
    ["5. Controlled training experiment", "Premium 10.0× → 3.0× → 1.9× as the mix becomes balanced; English cost +47%"],
    ["Quality assurance", "26 automated tests; GPT-4o counts identical to OpenAI’s tiktoken ranks"],
  ], [3300, 5726], { leftCols: [1], size: 20 }));
  o.push(h2("6.3 Future Scope and Enhancements"));
  ["Measure Sarvam-1, IndicBERT v2, MuRIL and other India-built tokenizers with the existing pipeline, and compare them with Gemma 3.",
    "Run 07_m5_generation_benchmark.py on an Apple M5 laptop to turn the premium into measured seconds and memory for Qwen2.5-0.5B, Llama 3.2-1B and Gemma 3-1B.",
    "Extend the corpus to informal, code-mixed (Hinglish) and romanised text, which dominate real chat traffic.",
    "Measure answer quality alongside token counts, to test whether lower premiums also mean better answers.",
    "Train full-size Indian-aware tokenizers on large corpora and test vocabulary-extension methods that add Indian tokens to an existing model.",
    "Publish the results as an interactive dashboard that is refreshed automatically whenever a new open model is released."].forEach(t => o.push(bullet(t)));
  return o;
}

// ------------------------------------------------------------------ references + appendices
const REFS = [
  "A. Petrov, E. La Malfa, P. H. S. Torr, and A. Bibi, “Language model tokenizers introduce unfairness between languages,” in Advances in Neural Information Processing Systems (NeurIPS), vol. 36, 2023.",
  "O. Ahia, S. Kumar, H. Gonen, J. Kasai, D. R. Mortensen, N. A. Smith, and Y. Tsvetkov, “Do all languages cost the same? Tokenization in the era of commercial language models,” in Proc. EMNLP, 2023, pp. 9904–9923.",
  "P. Rust, J. Pfeiffer, I. Vulić, S. Ruder, and I. Gurevych, “How good is your tokenizer? On the monolingual performance of multilingual language models,” in Proc. ACL-IJCNLP, 2021, pp. 3118–3135.",
  "NLLB Team, M. R. Costa-jussà et al., “No language left behind: Scaling human-centered machine translation,” arXiv:2207.04672, 2022.",
  "N. Goyal et al., “The FLORES-101 evaluation benchmark for low-resource and multilingual machine translation,” Transactions of the Association for Computational Linguistics, vol. 10, pp. 522–538, 2022.",
  "R. Sennrich, B. Haddow, and A. Birch, “Neural machine translation of rare words with subword units,” in Proc. ACL, 2016, pp. 1715–1725.",
  "T. Kudo and J. Richardson, “SentencePiece: A simple and language independent subword tokenizer and detokenizer for neural text processing,” in Proc. EMNLP: System Demonstrations, 2018, pp. 66–71.",
  "T. Kudo, “Subword regularization: Improving neural network translation models with multiple subword candidates,” in Proc. ACL, 2018, pp. 66–75.",
  "A. Radford, J. Wu, R. Child, D. Luan, D. Amodei, and I. Sutskever, “Language models are unsupervised multitask learners,” OpenAI Technical Report, 2019.",
  "Y. Wu et al., “Google’s neural machine translation system: Bridging the gap between human and machine translation,” arXiv:1609.08144, 2016.",
  "D. Kakwani et al., “IndicNLPSuite: Monolingual corpora, evaluation benchmarks and pre-trained multilingual language models for Indian languages,” in Findings of EMNLP, 2020, pp. 4948–4961.",
  "S. Doddapaneni et al., “Towards leaving no Indic language behind: Building monolingual corpora, benchmark and models for Indic languages,” in Proc. ACL, 2023, pp. 12402–12426.",
  "Sarvam AI, “Sarvam-1: A 2B parameter language model optimized for Indian languages,” Oct. 2024. [Online]. Available: https://huggingface.co/sarvamai/sarvam-1",
  "Qwen Team, “Qwen2.5 technical report,” arXiv:2412.15115, 2024.",
  "A. Yang et al., “Qwen3 technical report,” arXiv:2505.09388, 2025.",
  "A. Grattafiori et al., “The Llama 3 herd of models,” arXiv:2407.21783, 2024.",
  "Gemma Team, “Gemma 2: Improving open language models at a practical size,” arXiv:2408.00118, 2024.",
  "Gemma Team, “Gemma 3 technical report,” arXiv:2503.19786, 2025.",
  "H. Touvron et al., “Llama 2: Open foundation and fine-tuned chat models,” arXiv:2307.09288, 2023.",
  "P. Zhang, G. Zeng, T. Wang, and W. Lu, “TinyLlama: An open-source small language model,” arXiv:2401.02385, 2024.",
  "Mistral AI, “Mistral NeMo,” Jul. 2024. [Online]. Available: https://mistral.ai/news/mistral-nemo",
  "OpenAI, “tiktoken: A fast BPE tokeniser for use with OpenAI’s models,” GitHub repository. [Online]. Available: https://github.com/openai/tiktoken",
  "OpenAI, “gpt-oss-120b & gpt-oss-20b model card,” arXiv:2508.10925, 2025.",
  "OpenAI, “API pricing.” [Online]. Available: https://openai.com/api/pricing/ (accessed Nov. 2026).",
  "B. Efron and R. J. Tibshirani, An Introduction to the Bootstrap. New York, NY, USA: Chapman & Hall/CRC, 1993.",
  "The Unicode Consortium, “Unicode Standard Annex #15: Unicode normalization forms.” [Online]. Available: https://unicode.org/reports/tr15/",
  "A. Hannun, J. Digani, A. Katharopoulos, and R. Collobert, “MLX: Efficient and flexible machine learning on Apple silicon,” GitHub repository, 2023. [Online]. Available: https://github.com/ml-explore/mlx",
  "T. Wolf et al., “Transformers: State-of-the-art natural language processing,” in Proc. EMNLP: System Demonstrations, 2020, pp. 38–45.",
  "Hugging Face, “Tokenizers: Fast state-of-the-art tokenizers optimized for research and production,” GitHub repository. [Online]. Available: https://github.com/huggingface/tokenizers",
  "A. Petrov, “tokenization-fairness: Code and FLORES-200 data for ‘Language model tokenizers introduce unfairness between languages’,” GitHub repository, 2023. [Online]. Available: https://github.com/AleksandarPetrov/tokenization-fairness",
  "A. Vaswani et al., “Attention is all you need,” in Advances in Neural Information Processing Systems (NeurIPS), vol. 30, 2017, pp. 5998–6008.",
  "Government of India, The Constitution of India, Eighth Schedule (Articles 344(1) and 351): Languages.",
  "M. Velayuthan and K. Sarveswaran, “Egalitarian language representation in language models: It all begins with tokenizers,” in Proc. COLING, 2025.",
];
function refs() {
  const o = [frontTitle("References")];
  REFS.forEach((r, i) => o.push(new Paragraph({ spacing: { after: 100, line: 276 }, indent: { left: 600, hanging: 600 }, alignment: AlignmentType.JUSTIFIED,
    children: [new TextRun({ text: `[${i + 1}]\t`, font: FONT, size: 22 }), new TextRun({ text: r, font: FONT, size: 22 })], tabStops: [{ type: "left", position: 600 }] })));
  return o;
}

function appendices() {
  const o = [];
  o.push(frontTitle("Appendix A: Development Environment and Installation Details"));
  o.push(P("The following commands reproduce the environment and the full study on macOS or Linux (on Windows use Git Bash or run the scripts one by one). No GPU is needed. On a machine with internet access the tokenizers are downloaded from the Hugging Face Hub on first use; Llama 3.2 and Gemma are loaded from openly accessible mirrors of the official tokenizer files."));
  o.push(...code([
    "cd tokenization-tax",
    "python3 -m venv .venv && source .venv/bin/activate",
    "pip install -r code/requirements.txt",
    "cd code",
    "./run_all.sh            # fetches FLORES-200, runs phases 1-6 and the tests",
    "",
    "# individual phases",
    "python 01_prepare_data.py",
    "python 02_tokenize.py pretrained nfc      # ~15 s",
    "python 02_tokenize.py pretrained raw      # NFC ablation",
    "python 03_train_tokenizers.py",
    "python 02_tokenize.py own nfc",
    "python 04_analyse.py && python 05_figures.py && python 06_examples.py",
    "python -m pytest tests -v                 # 26 tests",
    "",
    "# optional, Apple-silicon laptop (e.g. MacBook with M5)",
    "pip install mlx-lm",
    "python 07_m5_generation_benchmark.py mlx-community/Qwen2.5-0.5B-Instruct-4bit",
    "python 07_m5_generation_benchmark.py mlx-community/Llama-3.2-1B-Instruct-4bit",
    "python 07_m5_generation_benchmark.py mlx-community/gemma-3-1b-it-4bit",
  ]));
  o.push(P("To add a model, append an entry to TOKENIZERS in config.py, for example dict(key=\"sarvam1\", label=\"Sarvam-1\", hf=\"sarvamai/sarvam-1\", …), and re-run 02_tokenize.py and the following scripts. Sarvam-1 and IndicBERT v2 are already listed and are measured automatically when the Hub is reachable."));

  o.push(frontTitle("Appendix B: Sample Input / Output Screenshots"));
  o.push(P("**Sample input.** FLORES-200 devtest sentence 59 in English, Hindi, Tamil and Odia (after NFC normalisation):"));
  ["eng_Latn", "hin_Deva", "tam_Taml", "ory_Orya"].forEach(l => o.push(P(`${l}: ${data.examples[l].text}`, { align: AlignmentType.LEFT, run: { font: "Noto Sans Devanagari" } })));
  o.push(P("**Sample output.** Token-by-token segmentation of the Hindi sentence. Tokens are separated by “ | ”; “·” marks a leading space; “�” marks a sub-character byte fragment.", { before: 120 }));
  const fmt = (pieces) => pieces.map(s => s === "" ? "▁" : s.replace(/^ /, "·").replace(/\uFFFD+/g, "�")).join(" | ");
  o.push(tableCaption("Segmentation of Hindi sentence 59 by four tokenizers", "Table B.1"));
  o.push(table(["Tokenizer (tokens)", "Tokens"], ["gemma3", "gpt4o", "llama3_2", "qwen2_5"].map(k => [
    `${T[data.order.indexOf(k)]} (${data.examples.hin_Deva.tok[k].n})`, fmt(data.examples.hin_Deva.tok[k].pieces)]),
  [2000, 7026], { leftCols: [1], font: "Noto Sans Devanagari", size: 17 }));
  o.push(P("**Console output of the automated test suite.**", { before: 160 }));
  const testLines = data.tests.split("\n").filter(l => l.includes("PASSED") || l.includes("passed") || l.startsWith("platform"))
    .map(l => l.replace(/\s+\[\s*\d+%\]/, "").replace("tests/test_pipeline.py::", ""));
  const sh = testLines.filter(l => !l.startsWith("platform"));
  o.push(...code(["$ python -m pytest tests -v", ...sh.slice(0, sh.length)], 15));
  o.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 200 }, children: [new TextRun({ text: "Figure B.1: ", bold: true, font: FONT, size: 22 }), new TextRun({ text: "Console output of the automated test suite (26 tests passed)", font: FONT, size: 22 })] }));
  FIGS.push({ id: "Figure B.1", caption: "Console output of the automated test suite (26 tests passed)" });
  o.push(P("**Console output of the tokenization phase.**"));
  o.push(...code([
    "$ python 02_tokenize.py pretrained nfc",
    "  gpt4o          vocab=200,000    1.4s",
    "  qwen2_5        vocab=151,665    1.7s",
    "  qwen3          vocab=151,669    1.8s",
    "  llama3_2       vocab=128,256    1.7s",
    "  gemma2         vocab=256,000    1.0s",
    "  gemma3         vocab=262,145    1.0s",
    "  mistral_nemo   vocab=131,072    1.3s",
    "  llama2         vocab= 32,000    1.4s",
    "saved 186,208 rows; round-trip exact: 100.0000%",
  ], 15));
  o.push(new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 200 }, children: [new TextRun({ text: "Figure B.2: ", bold: true, font: FONT, size: 22 }), new TextRun({ text: "Console output of the tokenization phase", font: FONT, size: 22 })] }));
  FIGS.push({ id: "Figure B.2", caption: "Console output of the tokenization phase" });

  o.push(frontTitle("Appendix C: Important Source Code"));
  o.push(P("**tokenizer_utils.py — fragment detection** (excerpt):"));
  o.push(...code([
    "_BYTE_FALLBACK = re.compile(r\"^<0x[0-9A-Fa-f]{2}>$\")",
    "",
    "def is_fragment(self, i):",
    "    \"\"\"True if a token is not a whole Unicode character on its own",
    "    (byte-fallback token or a partial UTF-8 byte sequence).\"\"\"",
    "    tok = self.id_to_token(i) or \"\"",
    "    if _BYTE_FALLBACK.match(tok):",
    "        return True",
    "    return \"\\ufffd\" in self.decode([i])",
  ], 16));
  o.push(P("**04_analyse.py — premium, bootstrap and practical metrics** (excerpt):"));
  o.push(...code([
    "boots = rng.integers(0, n, size=(C.N_BOOTSTRAP, n))   # paired resamples",
    "for tk, g in counts.groupby(\"tokenizer\"):",
    "    piv = g.pivot(index=\"sent_id\", columns=\"lang\", values=\"tokens\")",
    "    eng_tok = piv[ENG].to_numpy()",
    "    for lang, gl in g.groupby(\"lang\"):",
    "        t = piv[lang].to_numpy()",
    "        prem = t.sum() / eng_tok.sum()",
    "        bs = t[boots].sum(1) / eng_tok[boots].sum(1)",
    "        tok_per_eng_word = gl.tokens.sum() / eng_words.sum()",
    "        usd = tok_per_eng_word * 1000 * C.PRICE_PER_M_TOKENS_USD / 1e6",
    "        capacity = {w: w / tok_per_eng_word for w in C.CONTEXT_WINDOWS}",
  ], 16));
  o.push(P("**03_train_tokenizers.py — controlled BPE training** (excerpt):"));
  o.push(...code([
    "tok = Tokenizer(models.BPE())",
    "tok.normalizer = normalizers.NFC()",
    "tok.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=False)",
    "tok.decoder = decoders.ByteLevel()",
    "tr = trainers.BpeTrainer(vocab_size=8000, min_frequency=1,",
    "                         initial_alphabet=pre_tokenizers.ByteLevel.alphabet())",
    "tok.train_from_iterator(texts, trainer=tr)    # texts: one of the 3 mixes",
  ], 16));

  o.push(frontTitle("Appendix D: Additional Results and Supporting Documents"));
  o.push(tableCaption("Fertility (tokens per whitespace word) for English and the 12 main languages", "Table D.1"));
  o.push(table(["Language", ...T], data.fertility, [1450, 1080, 1080, 1080, 1080, 1100, 1080, 1076], { size: 18 }));
  o.push(tableCaption("Token premium vs English for the 10 extended languages", "Table D.2"));
  o.push(table(["Language", "Script", ...T], data.ext, [1300, 950, 968, 968, 968, 968, 968, 968, 968], { size: 17 }));
  o.push(...figureId(FIG("figD_1_extended_heatmap.png"), "Token premium for the extended languages", 6.2, "Figure D.1"));
  o.push(tableCaption("Summary of the pretrained tokenizers (main set of 12 languages)", "Table D.3"));
  o.push(table(["Tokenizer", "Vocabulary", "Eng. F", "Mean P", "Range of P", "Fragments %"],
    data.summary.map(r => [r[0], r[2], r[4], r[5], r[6], r[7]]), [2600, 1300, 1100, 1100, 1600, 1326], { size: 19 }));
  o.push(P("All per-sentence counts (sentence_counts_*.csv), per-language metrics (per_language_*.csv), summaries, the NFC ablation and the trained tokenizers are included in the results folder of the project.", { before: 120 }));
  return o;
}

// ------------------------------------------------------------------ assemble
let FIGS_FINAL = [], TABS_FINAL = [], HEADS_FINAL = [];
// dry run to collect figure / table / heading lists for the front lists
const bodyBlocks = body(); const refBlocks = refs(); const appBlocks = appendices();
FIGS_FINAL = FIGS.slice(); TABS_FINAL = TABS.slice();
HEADS_FINAL = HEADS.slice();
// reorder B figures after B tables in list: keep insertion order
const frontBlocks = front();
// front() pushed its own headings; put them first for TOC
const frontHeads = HEADS.slice(HEADS_FINAL.length);
HEADS_FINAL = [...frontHeads, { level: 1, text: "LIST OF FIGURES" }, { level: 1, text: "LIST OF TABLES" }, { level: 1, text: "LIST OF ABBREVIATIONS / NOTATIONS" }, { level: 1, text: "TABLE OF CONTENTS" }, ...HEADS_FINAL];
const listBlocks = lists();

const footer = new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 22 })] })] });
const numbering = { config: [
  { reference: "bul", levels: [{ level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] },
  ...NUMREFS.map(r => ({ reference: r, levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 720, hanging: 360 } } } }] })),
] };
const page = { size: { width: 11906, height: 16838 }, margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 } };
const doc = new Document({
  creator: STUDENT, title: TITLE_CASE, description: "Minor Project Report",
  styles: { default: { document: { run: { font: FONT, size: BODY } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true, run: { font: FONT, size: 32, bold: true }, paragraph: { spacing: { before: 0, after: 360 }, keepNext: true, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true, run: { font: FONT, size: 28, bold: true }, paragraph: { spacing: { before: 240, after: 120 }, keepNext: true, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true, run: { font: FONT, size: 24, bold: true }, paragraph: { spacing: { before: 180, after: 80 }, keepNext: true, outlineLevel: 2 } },
    ] },
  numbering,
  sections: [
    { properties: { page }, children: [...cover(), new Paragraph({ children: [new PageBreak()] }), ...cover()] },
    { properties: { page: { ...page, pageNumbers: { start: 1, formatType: NumberFormat.LOWER_ROMAN } } }, footers: { default: footer }, children: [...frontBlocks, ...listBlocks] },
    { properties: { page: { ...page, pageNumbers: { start: 1, formatType: NumberFormat.DECIMAL } } }, footers: { default: footer }, children: [...bodyBlocks, ...refBlocks, ...appBlocks] },
  ],
});
// first front title must not force a page break before (section already starts new page) - harmless
Packer.toBuffer(doc).then(b => {
  fs.writeFileSync(path.join(__dirname, "Minor_Project_Report_Mridul_Chaudhary.docx"), b);
  fs.writeFileSync(path.join(__dirname, "lists.json"), JSON.stringify({ figs: FIGS_FINAL, tabs: TABS_FINAL, heads: HEADS_FINAL }, null, 1));
  console.log("ok", FIGS_FINAL.length, "figs", TABS_FINAL.length, "tables", HEADS_FINAL.length, "heads");
});
