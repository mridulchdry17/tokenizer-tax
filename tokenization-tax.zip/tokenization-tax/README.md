# The Tokenization Tax — Indian languages in open small language models

Minor Project, B.Tech (AI & DS), ADGIPS — Mridul Chaudhary (04115611923), Section F-12.

Measures how many more tokens the same content needs in 22 Indian languages than in
English, for the tokenizers of free/open small models you can run on a MacBook (M5):
Qwen2.5/Qwen3, Llama 3.2, Gemma 2, Gemma 3, Mistral (Tekken), TinyLlama — plus GPT-4o
as a reference, and Sarvam-1 / IndicBERT v2 (measured automatically when online).

## Run everything (≈2 min, CPU only)
    python3 -m venv .venv && source .venv/bin/activate
    pip install -r code/requirements.txt
    cd code && ./run_all.sh

First run downloads FLORES-200 (GitHub) and the tokenizer files (Hugging Face Hub).
Llama/Gemma tokenizers come from public `unsloth/*` mirrors, so no Hugging Face login is needed.

## Optional: real models on Apple silicon
    pip install mlx-lm
    python 07_m5_generation_benchmark.py mlx-community/Qwen2.5-0.5B-Instruct-4bit
    python 07_m5_generation_benchmark.py mlx-community/Llama-3.2-1B-Instruct-4bit
    python 07_m5_generation_benchmark.py mlx-community/gemma-3-1b-it-4bit

## Folders
- `code/` scripts 01–07, `config.py`, tests
- `data/` FLORES-200 devtest/dev as CSV
- `results/` all counts, metrics, own tokenizers, test log
- `figures/` all report figures (+ Graphviz sources)
- `report/` report generator (`make.sh` → docx + pdf)
