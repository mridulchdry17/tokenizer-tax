"""Show how each tokenizer splits one real FLORES sentence (Appendix B)."""
import json, unicodedata
import pandas as pd
import config as C
from tokenizer_utils import load

SID = 59     # "Over four million people went to Rome to attend the funeral."
df = pd.read_csv(C.DATA_DIR / f"flores_{C.SPLIT}.csv")
out = {}
for lang in ["eng_Latn", "hin_Deva", "tam_Taml", "ory_Orya"]:
    text = unicodedata.normalize("NFC", df[(df.lang == lang) & (df.sent_id == SID)].text.iloc[0])
    out[lang] = {"text": text, "tok": {}}
    for t in C.TOKENIZERS + C.OWN_TOKENIZERS:
        if t["key"] == "qwen3":
            continue
        try:
            tk = load(t["key"])
        except Exception:
            continue
        ids = tk.encode(text)
        pieces = [tk.decode([i]) for i in ids]
        out[lang]["tok"][t["key"]] = dict(n=len(ids), pieces=pieces,
                                          fragments=sum(tk.is_fragment(i) for i in ids))
json.dump(out, open(C.RESULTS_DIR / "examples.json", "w"), ensure_ascii=False, indent=1)
for lang, v in out.items():
    print(lang, v["text"][:70], {k: d["n"] for k, d in v["tok"].items()})
