"""Uniform loading and counting for every tokenizer in the study."""
from functools import lru_cache
import re
import config as C

_BYTE_FALLBACK = re.compile(r"^<0x[0-9A-Fa-f]{2}>$")


class Tok:
    """Thin wrapper giving every tokenizer the same encode/decode interface."""

    def __init__(self, key, backend, obj):
        self.key, self.backend, self.obj = key, backend, obj

    def encode(self, text):
        if self.backend == "hf-tokenizers":
            return self.obj.encode(text, add_special_tokens=False).ids
        return self.obj.encode(text, add_special_tokens=False)   # transformers

    def decode(self, ids):
        return self.obj.decode(ids)

    def id_to_token(self, i):
        if self.backend == "hf-tokenizers":
            return self.obj.id_to_token(i)
        return self.obj.convert_ids_to_tokens(i)

    @property
    def vocab_size(self):
        if self.backend == "hf-tokenizers":
            return self.obj.get_vocab_size()
        return len(self.obj)

    def is_fragment(self, i):
        """True if a token is not a whole Unicode character on its own
        (byte-fallback token or a partial UTF-8 byte sequence)."""
        tok = self.id_to_token(i) or ""
        if _BYTE_FALLBACK.match(tok):
            return True
        return "�" in self.decode([i])


@lru_cache(maxsize=None)
def load(key: str) -> Tok:
    from tokenizers import Tokenizer
    spec = {t["key"]: t for t in C.TOKENIZERS}.get(key)
    own = C.RESULTS_DIR / "own_tokenizers" / f"{key}.json"
    if own.exists():
        return Tok(key, "hf-tokenizers", Tokenizer.from_file(str(own)))
    if spec is None:
        raise KeyError(key)
    for cand in (C.TOK_DIR / spec["local"] / "tokenizer.json",
                 C.TOK_DIR / spec["local"] / "package" / "models" / "tokenizer.json"):
        if cand.exists():
            return Tok(key, "hf-tokenizers", Tokenizer.from_file(str(cand)))
    try:                                   # needs internet (Hugging Face Hub)
        return Tok(key, "hf-tokenizers", Tokenizer.from_pretrained(spec["hf"]))
    except Exception:
        from transformers import AutoTokenizer
        return Tok(key, "transformers", AutoTokenizer.from_pretrained(spec["hf"]))


def words(text: str) -> int:
    """Whitespace word count (the unit used for 'tokens per word')."""
    return len(text.split())
