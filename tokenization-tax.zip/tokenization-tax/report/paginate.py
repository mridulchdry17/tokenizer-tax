"""Read page numbers of headings/captions from the rendered PDF -> pages.json"""
import json, re, subprocess, sys, unicodedata
pdf = sys.argv[1]
n = int(re.search(r"Pages:\s+(\d+)", subprocess.run(["pdfinfo", pdf], capture_output=True, text=True).stdout).group(1))
pages = [subprocess.run(["pdftotext", "-layout", "-f", str(i), "-l", str(i), pdf, "-"], capture_output=True, text=True).stdout for i in range(1, n + 1)]
norm = lambda s: re.sub(r"\s+", " ", unicodedata.normalize("NFC", s)).strip()
lines = [[norm(l) for l in p.splitlines() if l.strip()] for p in pages]
L = json.load(open("lists.json"))
# body start: first page whose first line is "Chapter 1: Introduction" (not TOC)
body = next(i for i, ls in enumerate(lines) if ls and ls[0].startswith("Chapter 1: Introduction"))
front_start = next(i for i, ls in enumerate(lines) if ls and ls[0].startswith("DECLARATION BY THE STUDENT"))  # page i
roman = lambda k: ["i","ii","iii","iv","v","vi","vii","viii","ix","x","xi","xii","xiii","xiv","xv","xvi","xvii","xviii","xix","xx"][k-1]
label = lambda i: roman(i - front_start + 1) if i < body else str(i - body + 1)
out = {}
def find(prefix, start, end=None, first_line=False):
    for i in range(start, end or n):
        for j, l in enumerate(lines[i]):
            if (j == 0 or not first_line) and l.startswith(prefix):
                return i
    return None
front_titles = {"DECLARATION BY THE STUDENT","CERTIFICATE BY THE SUPERVISOR","ABSTRACT","ACKNOWLEDGEMENT","LIST OF FIGURES","LIST OF TABLES","LIST OF ABBREVIATIONS / NOTATIONS","TABLE OF CONTENTS"}
for h in L["heads"]:
    t = h["text"]
    i = find(t, front_start, body, True) if t in front_titles else find(t[:60], body)
    if i is None: print("MISSING", t); continue
    out["H:" + t] = label(i)
for f in L["figs"] + L["tabs"]:
    i = find(f["id"] + ":", body)
    if i is None: print("MISSING", f["id"]); continue
    out[f["id"]] = label(i)
json.dump(out, open("pages.json", "w"), indent=1)
print("pages", n, "body starts pdf page", body + 1, "entries", len(out))
