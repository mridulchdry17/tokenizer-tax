// Helpers for building the report with docx-js
const fs = require("fs");
const path = require("path");
const D = require("docx");
const { Paragraph, TextRun, ImageRun, Table, TableRow, TableCell, AlignmentType, WidthType,
  BorderStyle, ShadingType, PageBreak, HeadingLevel, LevelFormat, PositionalTab,
  PositionalTabAlignment, PositionalTabRelativeTo, PositionalTabLeader } = D;

const FONT = "Times New Roman";
const BODY = 24;            // 12 pt
const LINE = 360;           // 1.5 line spacing
const CONTENT_W = 9026;     // A4 width 11906 - 2 x 1440 margins

const FIGS = [], TABS = [], HEADS = [];   // for the lists / TOC
let chap = 0, figN = 0, tabN = 0, eqN = 0;

// inline markup: **bold**, *italic*, `code`
function runs(text, base = {}) {
  const out = [];
  const re = /(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`)/g;
  let last = 0, m;
  while ((m = re.exec(text))) {
    if (m.index > last) out.push(new TextRun({ text: text.slice(last, m.index), font: FONT, size: BODY, ...base }));
    const t = m[0];
    if (t.startsWith("**")) out.push(new TextRun({ text: t.slice(2, -2), bold: true, font: FONT, size: BODY, ...base }));
    else if (t.startsWith("`")) out.push(new TextRun({ text: t.slice(1, -1), font: "Consolas", size: BODY - 3, ...base }));
    else out.push(new TextRun({ text: t.slice(1, -1), italics: true, font: FONT, size: BODY, ...base }));
    last = m.index + t.length;
  }
  if (last < text.length) out.push(new TextRun({ text: text.slice(last), font: FONT, size: BODY, ...base }));
  return out;
}

const P = (text, o = {}) => new Paragraph({
  children: runs(text, o.run || {}), alignment: o.align || AlignmentType.JUSTIFIED,
  spacing: { line: o.line || LINE, after: o.after ?? 120, before: o.before ?? 0 },
  indent: o.indent, keepNext: o.keepNext, pageBreakBefore: o.pageBreakBefore,
});
const C = (text, o = {}) => P(text, { ...o, align: AlignmentType.CENTER });
const blank = (n = 1) => Array.from({ length: n }, () => new Paragraph({ children: [new TextRun({ text: "", size: BODY })] }));
const pageBreak = () => new Paragraph({ children: [new PageBreak()] });

function chapter(title) {           // "Chapter n: Title"
  chap += 1; figN = 0; tabN = 0; eqN = 0;
  const t = `Chapter ${chap}: ${title}`;
  HEADS.push({ level: 1, text: t });
  return new Paragraph({ heading: HeadingLevel.HEADING_1, pageBreakBefore: true, alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: t, font: FONT, size: 32, bold: true })], spacing: { after: 360 } });
}
function frontTitle(t, list = true) { // unnumbered front-matter / back-matter title
  if (list) HEADS.push({ level: 1, text: t });
  return new Paragraph({ heading: HeadingLevel.HEADING_1, pageBreakBefore: true, alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: t, font: FONT, size: 32, bold: true })], spacing: { after: 360 } });
}
function h2(t) {
  HEADS.push({ level: 2, text: t });
  return new Paragraph({ heading: HeadingLevel.HEADING_2, keepNext: true, spacing: { before: 240, after: 120 },
    children: [new TextRun({ text: t, font: FONT, size: 28, bold: true })] });
}
function h3(t) {
  HEADS.push({ level: 3, text: t });
  return new Paragraph({ heading: HeadingLevel.HEADING_3, keepNext: true, spacing: { before: 180, after: 80 },
    children: [new TextRun({ text: t, font: FONT, size: BODY, bold: true })] });
}
const bullet = (text) => new Paragraph({ numbering: { reference: "bul", level: 0 }, children: runs(text),
  alignment: AlignmentType.JUSTIFIED, spacing: { line: LINE, after: 60 } });
let numRef = 0;
function numbered(items) {
  numRef += 1; const ref = `num${numRef}`; NUMREFS.push(ref);
  return items.map(t => new Paragraph({ numbering: { reference: ref, level: 0 }, children: runs(t),
    alignment: AlignmentType.JUSTIFIED, spacing: { line: LINE, after: 60 } }));
}
const NUMREFS = [];

function figure(file, caption, widthIn = 6.2) {
  figN += 1; const id = `Figure ${chap}.${figN}`;
  return figureId(file, caption, widthIn, id);
}
function figureId(file, caption, widthIn, id) {
  FIGS.push({ id, caption });
  const buf = fs.readFileSync(file);
  const { w, h } = pngSize(buf);
  const W = Math.round(widthIn * 96), H = Math.round(W * h / w);
  return [
    new Paragraph({ alignment: AlignmentType.CENTER, keepNext: true, spacing: { before: 120, after: 60 },
      children: [new ImageRun({ data: buf, type: "png", transformation: { width: W, height: H },
        altText: { title: id, description: caption, name: id } })] }),
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 200, line: 276 },
      children: [new TextRun({ text: `${id}: `, bold: true, font: FONT, size: 22 }), new TextRun({ text: caption, font: FONT, size: 22 })] }),
  ];
}
function pngSize(buf) { return { w: buf.readUInt32BE(16), h: buf.readUInt32BE(20) }; }

function tableCaption(caption, idOverride) {
  let id = idOverride;
  if (!id) { tabN += 1; id = `Table ${chap}.${tabN}`; }
  TABS.push({ id, caption });
  return new Paragraph({ alignment: AlignmentType.CENTER, keepNext: true, spacing: { before: 160, after: 80, line: 276 },
    children: [new TextRun({ text: `${id}: `, bold: true, font: FONT, size: 22 }), new TextRun({ text: caption, font: FONT, size: 22 })] });
}
const thin = { style: BorderStyle.SINGLE, size: 4, color: "808080" };
function table(header, rows, widths, o = {}) {
  const total = widths.reduce((a, b) => a + b, 0);
  const fs_ = o.size || 20;
  const mk = (cells, isHead) => new TableRow({ tableHeader: isHead, cantSplit: true, children: cells.map((c, i) => new TableCell({
    width: { size: widths[i], type: WidthType.DXA },
    borders: { top: thin, bottom: thin, left: thin, right: thin },
    shading: isHead ? { type: ShadingType.CLEAR, color: "auto", fill: "D9E2F3" } : undefined,
    margins: { top: 40, bottom: 40, left: 80, right: 80 },
    children: [new Paragraph({ alignment: (i === 0 || (o.leftCols || []).includes(i)) ? AlignmentType.LEFT : AlignmentType.CENTER,
      spacing: { line: 240, after: 0 },
      children: [new TextRun({ text: String(c), bold: isHead || (o.boldLast && cells === rows[rows.length - 1]), font: o.font || FONT, size: fs_ })] })],
  })) });
  return new Table({ width: { size: total, type: WidthType.DXA }, columnWidths: widths, alignment: AlignmentType.CENTER,
    rows: [mk(header, true), ...rows.map(r => mk(r, false))] });
}
function equation(text) {
  eqN += 1;
  return new Paragraph({ alignment: AlignmentType.LEFT, spacing: { before: 120, after: 120 },
    tabStops: [{ type: D.TabStopType.CENTER, position: Math.round(CONTENT_W / 2) }, { type: D.TabStopType.RIGHT, position: CONTENT_W }],
    children: [new TextRun({ text: "\t", font: FONT, size: BODY }), new TextRun({ text, italics: true, font: "Cambria Math", size: BODY }),
      new TextRun({ text: `\t(${chap}.${eqN})`, font: FONT, size: BODY })] });
}
function code(lines, size = 17) {
  return lines.map((l, i) => new Paragraph({ spacing: { line: 240, after: 0, before: i === 0 ? 80 : 0 },
    shading: { type: ShadingType.CLEAR, color: "auto", fill: "F2F2F2" }, indent: { left: 200 },
    children: [new TextRun({ text: l === "" ? " " : l, font: "Consolas", size })] }))
    .concat([new Paragraph({ spacing: { after: 120 }, children: [] })]);
}
function tocLine(text, page, level) {
  return new Paragraph({ spacing: { line: 320, after: 40 }, indent: { left: (level - 1) * 360, right: 500 },
    tabStops: [{ type: D.TabStopType.RIGHT, position: CONTENT_W, leader: D.LeaderType.DOT }],
    children: [new TextRun({ text, font: FONT, size: BODY }), new TextRun({ text: "\t" + String(page), font: FONT, size: BODY })] });
}

module.exports = { D, FONT, BODY, LINE, CONTENT_W, FIGS, TABS, HEADS, NUMREFS, runs, P, C, blank, pageBreak,
  chapter, frontTitle, h2, h3, bullet, numbered, figure, figureId, tableCaption, table, equation, code, tocLine,
  resetCounters: () => { chap = 0; } , setChap: (c) => { chap = c; figN = 0; tabN = 0; eqN = 0; } };
