"""Central configuration for the Tokenization Tax study.

Every script reads its settings from here, so the whole study can be re-run
or extended (new language, new tokenizer) by editing this one file.
"""
from pathlib import Path
import os

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
RESULTS_DIR = ROOT / "results"
FIG_DIR = ROOT / "figures"
TOK_DIR = Path(os.environ.get("TOKTAX_TOKENIZER_DIR", ROOT / "tokenizers"))

# FLORES-200 location. Clone once:
#   git clone --depth 1 https://github.com/AleksandarPetrov/tokenization-fairness
# and point FLORES_DIR at its flores200_dataset folder (or set env var).
FLORES_DIR = Path(os.environ.get("FLORES_DIR", ROOT / "flores200_dataset"))
SPLIT = "devtest"          # 1,012 sentences: used for ALL measurements
TRAIN_SPLIT = "dev"        # 997 sentences: used ONLY to train our own tokenizers

SEED = 42
N_BOOTSTRAP = 2000

# ---------------------------------------------------------------- languages
# 12 major Indian languages (main analysis) + 10 further varieties (extended).
REFERENCE = ("eng_Latn", "English", "Latin")
MAIN_LANGS = [
    ("hin_Deva", "Hindi", "Devanagari"),
    ("ben_Beng", "Bengali", "Bengali"),
    ("mar_Deva", "Marathi", "Devanagari"),
    ("tel_Telu", "Telugu", "Telugu"),
    ("tam_Taml", "Tamil", "Tamil"),
    ("urd_Arab", "Urdu", "Perso-Arabic"),
    ("guj_Gujr", "Gujarati", "Gujarati"),
    ("kan_Knda", "Kannada", "Kannada"),
    ("mal_Mlym", "Malayalam", "Malayalam"),
    ("ory_Orya", "Odia", "Odia"),
    ("pan_Guru", "Punjabi", "Gurmukhi"),
    ("asm_Beng", "Assamese", "Bengali"),
]
EXTENDED_LANGS = [
    ("mai_Deva", "Maithili", "Devanagari"),
    ("san_Deva", "Sanskrit", "Devanagari"),
    ("npi_Deva", "Nepali", "Devanagari"),
    ("snd_Arab", "Sindhi", "Perso-Arabic"),
    ("kas_Arab", "Kashmiri", "Perso-Arabic"),
    ("mni_Beng", "Manipuri (Meitei)", "Bengali"),
    ("sat_Olck", "Santali", "Ol Chiki"),
    ("bho_Deva", "Bhojpuri", "Devanagari"),
    ("awa_Deva", "Awadhi", "Devanagari"),
    ("mag_Deva", "Magahi", "Devanagari"),
]
ALL_LANGS = [REFERENCE] + MAIN_LANGS + EXTENDED_LANGS
LANG_NAME = {c: n for c, n, _ in ALL_LANGS}
LANG_SCRIPT = {c: s for c, _, s in ALL_LANGS}

# ---------------------------------------------------------------- tokenizers
# key: short id. local: folder under TOK_DIR holding tokenizer.json.
# hf: Hugging Face repo used when the local copy is absent (e.g. on the M5 Mac).
# All are free/open checkpoints that run on an Apple-silicon laptop
# (except GPT-4o, which is included only as the closed-model reference).
TOKENIZERS = [
    dict(key="gpt4o", label="GPT-4o / gpt-oss (o200k)", models="GPT-4o (API, reference); gpt-oss-20b (open)",
         vocab_family="byte-level BPE", hf="Xenova/gpt-4o", local="gpt4o", origin="USA", open=False),
    dict(key="qwen2_5", label="Qwen2.5", models="Qwen2.5-0.5B / 1.5B / 3B-Instruct",
         vocab_family="byte-level BPE", hf="Qwen/Qwen2.5-0.5B-Instruct", local="qwen2_5", origin="China", open=True),
    dict(key="qwen3", label="Qwen3", models="Qwen3-0.6B / 1.7B / 4B",
         vocab_family="byte-level BPE", hf="Qwen/Qwen3-0.6B", local="qwen3", origin="China", open=True),
    dict(key="llama3_2", label="Llama 3.2", models="Llama-3.2-1B / 3B-Instruct",
         vocab_family="byte-level BPE", hf="unsloth/Llama-3.2-1B-Instruct", local="llama3_2", origin="USA", open=True),
    dict(key="gemma2", label="Gemma 2", models="Gemma-2-2B-it",
         vocab_family="SentencePiece BPE", hf="unsloth/gemma-2-2b-it", local="gemma2", origin="USA", open=True),
    dict(key="gemma3", label="Gemma 3", models="Gemma-3-1B / 4B-it",
         vocab_family="SentencePiece BPE", hf="unsloth/gemma-3-1b-it", local="gemma3", origin="USA", open=True),
    dict(key="mistral_nemo", label="Mistral (Tekken)", models="Mistral-NeMo-12B / Ministral-8B",
         vocab_family="byte-level BPE", hf="unsloth/Mistral-Nemo-Instruct-2407", local="mistral_nemo", origin="France", open=True),
    dict(key="llama2", label="TinyLlama / Llama 2 (32k)", models="TinyLlama-1.1B; Phi-3-mini; Llama-2-7B",
         vocab_family="SentencePiece BPE", hf="TinyLlama/TinyLlama-1.1B-Chat-v1.0", local="llama2", origin="USA", open=True),
    # India-built. Not reachable from the build sandbox; measured automatically
    # when 02_tokenize.py is run on a machine with Hugging Face access.
    dict(key="sarvam1", label="Sarvam-1", models="Sarvam-1 (2B)",
         vocab_family="SentencePiece BPE", hf="sarvamai/sarvam-1", local="sarvam1", origin="India", open=True),
    dict(key="indicbert2", label="IndicBERT v2", models="IndicBERT-v2 (encoder)",
         vocab_family="WordPiece", hf="ai4bharat/IndicBERTv2-MLM-only", local="indicbert2", origin="India", open=True),
]

# Tokenizers trained in this project (03_train_tokenizers.py)
OWN_VOCAB = 8_000
OWN_TOKENIZERS = [
    dict(key="own_eng", label="Own BPE: English-only", mix="english"),
    dict(key="own_skew", label="Own BPE: web-skewed mix", mix="skewed"),
    dict(key="own_bal", label="Own BPE: balanced (parity)", mix="balanced"),
]

# ---------------------------------------------------------------- economics
# Illustrative list price for a hosted model, USD per 1M input tokens
# (GPT-4o standard tier, OpenAI pricing page, checked Nov 2026).
PRICE_PER_M_TOKENS_USD = 2.50
CONTEXT_WINDOWS = [4_096, 8_192, 32_768, 128_000]
