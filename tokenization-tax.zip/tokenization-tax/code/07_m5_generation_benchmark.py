"""OPTIONAL - run on an Apple-silicon Mac (e.g. MacBook with M5).

Measures how the token premium turns into real waiting time on a laptop:
the same FLORES sentences are fed to a small local model in each language,
and prompt-processing time is recorded with Apple's MLX framework.

    pip install mlx-lm
    python 07_m5_generation_benchmark.py mlx-community/Qwen2.5-0.5B-Instruct-4bit
    python 07_m5_generation_benchmark.py mlx-community/Llama-3.2-1B-Instruct-4bit
    python 07_m5_generation_benchmark.py mlx-community/gemma-3-1b-it-4bit
    python 07_m5_generation_benchmark.py mlx-community/sarvam-1-4bit   # if available
"""
import sys, time, json, unicodedata
import pandas as pd
import config as C

LANGS = ["eng_Latn", "hin_Deva", "ben_Beng", "tam_Taml", "tel_Telu", "mal_Mlym", "ory_Orya"]
N_SENT = 50

def main(model_id):
    import mlx.core as mx
    from mlx_lm import load
    model, tok = load(model_id)
    df = pd.read_csv(C.DATA_DIR / f"flores_{C.SPLIT}.csv")
    rows = []
    for lang in LANGS:
        text = " ".join(unicodedata.normalize("NFC", s)
                        for s in df[df.lang == lang].sort_values("sent_id").text[:N_SENT])
        ids = mx.array([tok.encode(text)])
        model(ids[:, :8]); mx.eval(model.parameters())          # warm-up
        t0 = time.perf_counter(); out = model(ids); mx.eval(out); dt = time.perf_counter() - t0
        rows.append(dict(model=model_id, lang=lang, tokens=ids.shape[1], seconds=dt,
                         tokens_per_s=ids.shape[1] / dt))
        print(f"{lang}: {ids.shape[1]:6d} tokens  {dt*1000:8.1f} ms")
    eng = rows[0]["seconds"]
    for r in rows: r["time_vs_english"] = r["seconds"] / eng
    out = C.RESULTS_DIR / f"m5_{model_id.split('/')[-1]}.json"
    json.dump(rows, open(out, "w"), indent=1); print("saved", out)

if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "mlx-community/Qwen2.5-0.5B-Instruct-4bit")
