"""Phase 1 - load the FLORES-200 devtest (and dev) split for all languages,
check that the files are sentence-aligned and save one tidy CSV per split."""
import sys
import pandas as pd
import config as C


def load_split(split: str) -> pd.DataFrame:
    rows = []
    for code, name, script in C.ALL_LANGS:
        path = C.FLORES_DIR / split / f"{code}.{split}"
        if not path.exists():
            sys.exit(f"Missing {path}. See config.FLORES_DIR.")
        lines = path.read_text(encoding="utf-8").rstrip("\n").split("\n")
        for i, s in enumerate(lines):
            rows.append(dict(sent_id=i, lang=code, language=name, script=script, text=s.strip()))
    df = pd.DataFrame(rows)
    sizes = df.groupby("lang").size()
    assert sizes.nunique() == 1, f"Files not aligned: {sizes.to_dict()}"
    assert (df.text.str.len() > 0).all(), "Empty sentence found"
    return df


if __name__ == "__main__":
    C.DATA_DIR.mkdir(parents=True, exist_ok=True)
    for split in (C.SPLIT, C.TRAIN_SPLIT):
        df = load_split(split)
        out = C.DATA_DIR / f"flores_{split}.csv"
        df.to_csv(out, index=False)
        print(f"{split}: {df.lang.nunique()} languages x {df.sent_id.nunique()} sentences -> {out.name}")
    # leakage check: no devtest sentence occurs in dev
    dt = pd.read_csv(C.DATA_DIR / f"flores_{C.SPLIT}.csv")
    dv = pd.read_csv(C.DATA_DIR / f"flores_{C.TRAIN_SPLIT}.csv")
    overlap = set(dt.text) & set(dv.text)
    print(f"dev/devtest overlap: {len(overlap)} identical sentences")
